package ru.obhody.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

// SQLite schema is migrated in place. Completed and unsent results are NEVER dropped.
private class Store(context: Context) : SQLiteOpenHelper(context, "obhody_local.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE pending (id TEXT PRIMARY KEY, payload TEXT NOT NULL, synced INTEGER NOT NULL DEFAULT 0, owner_login TEXT NOT NULL DEFAULT '')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE pending ADD COLUMN owner_login TEXT NOT NULL DEFAULT ''")
    }
    fun save(payload: JSONObject, login: String) {
        writableDatabase.insertOrThrow("pending", null, ContentValues().apply {
            put("id", payload.getString("id")); put("payload", payload.toString()); put("synced", 0); put("owner_login", login)
        })
    }
    fun counts(login: String): Pair<Int, Int> {
        if (login.isBlank()) return 0 to 0
        return readableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM(CASE WHEN synced=0 THEN 1 ELSE 0 END),0) FROM pending WHERE owner_login=?",
            arrayOf(login)
        ).use { c -> c.moveToFirst(); c.getInt(0) to c.getInt(1) }
    }
    fun legacyCount(): Int = readableDatabase.rawQuery(
        "SELECT COUNT(*) FROM pending WHERE owner_login='' AND synced=0", null
    ).use { c -> c.moveToFirst(); c.getInt(0) }
    fun adoptLegacy(login: String) {
        writableDatabase.update("pending", ContentValues().apply { put("owner_login", login) },
            "owner_login='' AND synced=0", null)
    }
    fun unsynced(login: String): JSONArray {
        val arr = JSONArray()
        readableDatabase.rawQuery("SELECT payload FROM pending WHERE synced=0 AND owner_login=? LIMIT 100", arrayOf(login)).use { c ->
            while(c.moveToNext()) arr.put(JSONObject(c.getString(0)))
        }
        return arr
    }
    fun markSynced(ids: JSONArray, login: String) {
        writableDatabase.beginTransaction()
        try {
            for(i in 0 until ids.length()) {
                writableDatabase.update("pending", ContentValues().apply {put("synced",1)},
                    "id=? AND owner_login=?", arrayOf(ids.getString(i), login))
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
    fun history(login: String): List<JSONObject> {
        val results = mutableListOf<JSONObject>()
        if (login.isBlank()) return results
        readableDatabase.rawQuery("SELECT payload, synced FROM pending WHERE owner_login=? ORDER BY rowid DESC LIMIT 60", arrayOf(login)).use { c ->
            while(c.moveToNext()) results.add(JSONObject(c.getString(0)).put("_synced", c.getInt(1) == 1))
        }
        return results
    }
}

private fun http(base: String, token: String, path: String, method: String = "GET", payload: String? = null): String {
    val normalized = base.trim().trimEnd('/')
    require(normalized.startsWith("https://") || (BuildConfig.DEBUG && normalized.startsWith("http://"))) {
        "Нужен HTTPS. HTTP разрешён только в тестовой версии для локальной сети"
    }
    val url = URL(normalized + path)
    val conn = url.openConnection() as HttpURLConnection
    try {
        conn.requestMethod = method
        conn.connectTimeout = 7000
        conn.readTimeout = 15000
        conn.setRequestProperty("Accept", "application/json")
        if(token.isNotEmpty()) conn.setRequestProperty("Authorization", "Bearer $token")
        if(payload != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val text = (if(code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use {it.readText()} ?: ""
        if(code !in 200..299) {
            val detail = runCatching { JSONObject(text).optString("detail") }.getOrDefault("")
            throw IllegalStateException(if(code == 401) "Сеанс закончился. Войдите снова" else "HTTP $code ${detail.take(160)}")
        }
        return text
    } finally {conn.disconnect()}
}

private val Indigo = Color(0xFF365ED6)
private val Navy = Color(0xFF173550)
private val Canvas = Color(0xFFF4F7FD)
private fun prettyDate(iso: String): String = runCatching {
    DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault()).format(Instant.parse(iso))
}.getOrElse {iso}

@Composable
private fun FilledPanel(content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp), colors=CardDefaults.elevatedCardColors(containerColor=Color.White)) {
        Column(modifier=Modifier.fillMaxWidth().padding(17.dp), verticalArrangement=Arrangement.spacedBy(10.dp),content=content)
    }
}

@Composable
private fun Header(title: String, subtitle: String = "") {
    Column(verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold,color=Navy)
        if(subtitle.isNotBlank()) Text(subtitle,style=MaterialTheme.typography.bodyMedium,color=Color(0xFF6D7C90))
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        setContent {
            val scheme = lightColorScheme(primary=Indigo, secondary=Navy, background=Canvas, surface=Color.White)
            var server by remember { mutableStateOf(prefs.getString("server", "http://192.168.0.20:8000") ?: "") }
            var loginName by remember { mutableStateOf(prefs.getString("user_login", "") ?: "") }
            var fullName by remember { mutableStateOf(prefs.getString("user_name", "") ?: "") }
            var userRole by remember { mutableStateOf(prefs.getString("user_role", "") ?: "") }
            var token by remember { mutableStateOf(prefs.getString("auth_token", "") ?: "") }
            var password by remember { mutableStateOf("") }
            var page by remember { mutableStateOf(if(token.isNotEmpty() && loginName.isNotEmpty()) "home" else "login") }
            var routes by remember { mutableStateOf(JSONArray(prefs.getString("routes_$loginName", "[]") ?: "[]")) }
            var routeQuery by remember { mutableStateOf("") }
            var selectedRouteIndex by remember { mutableIntStateOf(0) }
            var selectedCheckpoint by remember { mutableIntStateOf(0) }
            var answers by remember { mutableStateOf(mapOf<String,String>()) }
            var comment by remember { mutableStateOf("") }
            var message by remember { mutableStateOf("") }
            var busy by remember { mutableStateOf(false) }
            var counts by remember { mutableStateOf(store.counts(loginName)) }
            var legacyCount by remember { mutableIntStateOf(store.legacyCount()) }
            var history by remember { mutableStateOf(store.history(loginName)) }
            var oldPassword by remember { mutableStateOf("") }
            var newPassword by remember { mutableStateOf("") }
            var showLegacyConfirm by remember { mutableStateOf(false) }

            fun updateLocal() {
                counts=store.counts(loginName)
                history=store.history(loginName)
                legacyCount=store.legacyCount()
            }
            fun doNetwork(action: () -> String) {
                if (busy) return
                busy = true; message = ""
                Thread {
                    val result = runCatching { action() }
                    runOnUiThread { busy = false; updateLocal(); message = result.fold({it},{"Ошибка: ${it.message}"}) }
                }.start()
            }
            fun logOut() {
                val oldToken=token
                val oldServer=server
                if(oldToken.isNotBlank()) Thread { runCatching {http(oldServer,oldToken,"/api/auth/logout","POST")} }.start()
                prefs.edit().remove("auth_token").remove("user_login").remove("user_name").remove("user_role").apply()
                token="";loginName="";fullName="";userRole="";password="";routes=JSONArray();counts=0 to 0;page="login";message=""
            }
            BackHandler(page=="form" || page=="history" || page=="settings") { page="home" }
            MaterialTheme(colorScheme=scheme) {
                if(showLegacyConfirm) AlertDialog(
                    onDismissRequest={showLegacyConfirm=false},
                    title={Text("Старые обходы")},
                    text={Text("Привязать $legacyCount ранее сохранённых, ещё не отправленных обходов к текущему сотруднику $fullName? Это действие нельзя отменить.")},
                    confirmButton={TextButton(onClick={store.adoptLegacy(loginName);updateLocal();showLegacyConfirm=false;message="Старые обходы привязаны"}){Text("Привязать")}},
                    dismissButton={TextButton(onClick={showLegacyConfirm=false}){Text("Отмена")}}
                )
                Scaffold(containerColor=Canvas, bottomBar={
                    if(page!="login" && page!="form") NavigationBar(containerColor=Color.White) {
                        NavigationBarItem(selected=page=="home",onClick={page="home"},icon={Text("☑")},label={Text("Маршруты")})
                        NavigationBarItem(selected=page=="history",onClick={updateLocal();page="history"},icon={Text("▤")},label={Text("История")})
                        NavigationBarItem(selected=page=="settings",onClick={page="settings"},icon={Text("⚙")},label={Text("Профиль")})
                    }
                }) { insets ->
                    Column(modifier=Modifier.fillMaxSize().padding(insets).verticalScroll(rememberScrollState()).padding(18.dp),
                        verticalArrangement=Arrangement.spacedBy(16.dp)) {
                        if(page == "login") {
                            Spacer(Modifier.height(35.dp))
                            Text("✓",style=MaterialTheme.typography.displayLarge,color=Indigo)
                            Header("Обходы", "Вход для сотрудников")
                            FilledPanel {
                                OutlinedTextField(value=server,onValueChange={server=it},label={Text("Адрес сервера")},
                                    placeholder={Text("http://192.168.0.20:8000")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(value=loginName,onValueChange={loginName=it.trim()},label={Text("Логин")},
                                    singleLine=true,modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(value=password,onValueChange={password=it},label={Text("Пароль")},
                                    visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth())
                                Button(onClick={doNetwork {
                                    require(loginName.isNotBlank() && password.isNotBlank()) {"Укажите логин и пароль"}
                                    prefs.edit().putString("server",server.trim()).apply()
                                    val body=JSONObject().put("login",loginName.trim()).put("password",password)
                                    val response=JSONObject(http(server,"","/api/auth/login","POST",body.toString()))
                                    val user=response.getJSONObject("user")
                                    val receivedToken=response.getString("access_token")
                                    val receivedLogin=user.getString("login")
                                    val receivedName=user.getString("full_name")
                                    val receivedRole=user.getString("role")
                                    prefs.edit().putString("auth_token",receivedToken).putString("user_login",receivedLogin)
                                        .putString("user_name",receivedName).putString("user_role",receivedRole).apply()
                                    runOnUiThread {
                                        loginName=receivedLogin;fullName=receivedName;userRole=receivedRole
                                        token=receivedToken;password="";routes=JSONArray(prefs.getString("routes_$receivedLogin", "[]") ?: "[]")
                                        updateLocal();page="home"
                                    }
                                    "Вход выполнен"
                                }},enabled=!busy,modifier=Modifier.fillMaxWidth()) {Text(if(busy)"Подключение..." else "Войти")}
                            }
                            Text("Для тестов можно использовать HTTP внутри доверенной сети. Для реальной эксплуатации с персональными паролями обязательно настройте HTTPS.",color=Color(0xFF9B6133),style=MaterialTheme.typography.bodySmall)
                        }
                        if(page != "login") {
                            Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                                Text("✓ Обходы",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.weight(1f))
                                Text(fullName,style=MaterialTheme.typography.labelMedium,color=Color.DarkGray)
                            }
                        }
                        if(message.isNotBlank()) Surface(color=Color(0xFFE9F0FF),shape=RoundedCornerShape(12.dp)) {
                            Text(message,Modifier.fillMaxWidth().padding(13.dp),color=Navy)
                        }
                        when(page) {
                            "home" -> {
                                Header("Мои маршруты","Выберите обход и приступайте к проверке")
                                FilledPanel {
                                    Text("Локальные результаты",style=MaterialTheme.typography.titleMedium)
                                    Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
                                        Text("Сохранено: ${counts.first}")
                                        Text("К отправке: ${counts.second}",fontWeight=FontWeight.Bold,color=if(counts.second>0) Indigo else Color(0xFF238663))
                                    }
                                    Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                                        Button(onClick={doNetwork {
                                            val data=http(server,token,"/api/routes")
                                            val loaded=JSONArray(data)
                                            prefs.edit().putString("routes_$loginName",data).apply()
                                            runOnUiThread{routes=loaded}
                                            "Маршрутов загружено: ${loaded.length()}"
                                        }},enabled=!busy,modifier=Modifier.weight(1f)) {Text("Обновить маршруты")}
                                        OutlinedButton(onClick={doNetwork {
                                            var sent=0
                                            while(true){
                                                val items=store.unsynced(loginName)
                                                if(items.length()==0)break
                                                val response=JSONObject(http(server,token,"/api/inspections/batch","POST",items.toString()))
                                                val ids=response.getJSONArray("saved_ids")
                                                if(ids.length()!=items.length())throw IllegalStateException("Сервер принял не все результаты")
                                                store.markSynced(ids,loginName)
                                                sent+=ids.length()
                                            }
                                            "Отправлено: $sent"
                                        }},enabled=!busy,modifier=Modifier.weight(1f)) {Text("Отправить (${counts.second})")}
                                    }
                                }
                                OutlinedTextField(value=routeQuery,onValueChange={routeQuery=it},label={Text("Поиск маршрута")},modifier=Modifier.fillMaxWidth())
                                var visible=0
                                for(i in 0 until routes.length()) {
                                    val route=routes.getJSONObject(i)
                                    if(!route.optString("name").contains(routeQuery,ignoreCase=true))continue
                                    visible++
                                    FilledPanel {
                                        Text(route.optString("name"),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,color=Navy)
                                        if(route.optString("description").isNotBlank())Text(route.optString("description"),color=Color.Gray)
                                        Text("Контрольных точек: ${route.optJSONArray("checkpoints")?.length() ?: 0}",style=MaterialTheme.typography.labelMedium)
                                        Button(onClick={selectedRouteIndex=i;selectedCheckpoint=0;answers=emptyMap();comment="";message="";page="form"},modifier=Modifier.fillMaxWidth()) {Text("Начать обход")}
                                    }
                                }
                                if(visible==0) Text(if(routes.length()==0)"Маршруты ещё не загружены. Нажмите «Обновить маршруты»." else "По вашему запросу маршруты не найдены.",color=Color.Gray)
                            }
                            "form" -> {
                                if(selectedRouteIndex >= routes.length()) {
                                    Text("Маршрут не найден"); Button(onClick={page="home"}){Text("Назад")}
                                } else {
                                    val route=routes.getJSONObject(selectedRouteIndex)
                                    val checkpoints=route.getJSONArray("checkpoints")
                                    val cp=checkpoints.getJSONObject(selectedCheckpoint)
                                    Header(route.getString("name"),"Контрольная точка ${selectedCheckpoint+1} из ${checkpoints.length()}")
                                    LinearProgressIndicator(progress={ (selectedCheckpoint+1).toFloat()/checkpoints.length().coerceAtLeast(1) },modifier=Modifier.fillMaxWidth())
                                    FilledPanel {
                                        Text(cp.getString("title"),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Navy)
                                        val questions=cp.getJSONArray("questions")
                                        for(q in 0 until questions.length()) {
                                            val question=questions.getJSONObject(q)
                                            val questionId=question.getString("id")
                                            val value=answers[questionId]?:""
                                            val kind=question.getString("kind")
                                            Text(question.getString("title")+(if(question.optBoolean("required"))" *" else ""),fontWeight=FontWeight.SemiBold)
                                            if(kind=="status" || kind=="choice") {
                                                val choices=if(kind=="status") listOf("Норма","Дефект","Не проверено") else question.optJSONArray("options")?.let{ opts ->(0 until opts.length()).map { opts.getString(it) } } ?: emptyList()
                                                for(choice in choices) {
                                                    val selected=value==choice
                                                    Surface(modifier=Modifier.fillMaxWidth().clickable {answers=answers+(questionId to choice)},
                                                        shape=RoundedCornerShape(12.dp),border=BorderStroke(1.dp,if(selected) Indigo else Color(0xFFE1E7F1)),
                                                        color=if(selected)Color(0xFFEEF3FF) else Color.White) {
                                                        Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(horizontal=9.dp)) {
                                                            RadioButton(selected=selected,onClick={answers=answers+(questionId to choice)})
                                                            Text(choice,modifier=Modifier.padding(start=5.dp))
                                                        }
                                                    }
                                                }
                                            } else {
                                                OutlinedTextField(value=value,onValueChange={answers=answers+(questionId to it)},
                                                    label={Text(if(kind=="number")"Введите число" else "Введите ответ")},
                                                    keyboardOptions=KeyboardOptions(keyboardType=if(kind=="number")KeyboardType.Decimal else KeyboardType.Text),
                                                    modifier=Modifier.fillMaxWidth(),minLines=1)
                                            }
                                            HorizontalDivider(color=Color(0xFFE9EDF4))
                                        }
                                    }
                                    if(selectedCheckpoint==checkpoints.length()-1) {
                                        OutlinedTextField(value=comment,onValueChange={comment=it},label={Text("Комментарий к обходу")},modifier=Modifier.fillMaxWidth(),minLines=3)
                                    }
                                    fun requiredAnswered(): Boolean {
                                        for(c in 0 until checkpoints.length()){
                                            val qs=checkpoints.getJSONObject(c).getJSONArray("questions")
                                            for(q in 0 until qs.length()){
                                                val question=qs.getJSONObject(q);if(!question.optBoolean("required"))continue
                                                val v=answers[question.getString("id")]?:""
                                                if(v.isBlank() || (question.optString("kind")=="number" && v.replace(',','.').toDoubleOrNull()==null))return false
                                            }
                                        }
                                        return true
                                    }
                                    val nextEnabled=run {
                                        val qs=cp.getJSONArray("questions")
                                        var good=true
                                        for(q in 0 until qs.length()) {
                                            val question=qs.getJSONObject(q)
                                            val value=answers[question.getString("id")]?:""
                                            if(question.optBoolean("required") && (value.isBlank() || (question.optString("kind")=="number" && value.replace(',','.').toDoubleOrNull()==null))) good=false
                                        }
                                        good
                                    }
                                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxWidth()) {
                                        OutlinedButton(onClick={if(selectedCheckpoint>0)selectedCheckpoint-- else page="home"},modifier=Modifier.weight(1f)) {Text("Назад")}
                                        if(selectedCheckpoint<checkpoints.length()-1) {
                                            Button(onClick={selectedCheckpoint++},enabled=nextEnabled,modifier=Modifier.weight(1f)) {Text("Далее")}
                                        } else {
                                            Button(onClick={
                                                val all=JSONArray()
                                                for(c in 0 until checkpoints.length()) {
                                                    val checkpoint=checkpoints.getJSONObject(c)
                                                    val qs=checkpoint.getJSONArray("questions")
                                                    for(q in 0 until qs.length()){
                                                        val question=qs.getJSONObject(q)
                                                        all.put(JSONObject().put("checkpoint_id",checkpoint.getString("id"))
                                                            .put("question_id",question.getString("id")).put("question",question.getString("title"))
                                                            .put("value",answers[question.getString("id")]?:""))
                                                    }
                                                }
                                                val payload=JSONObject().put("id",UUID.randomUUID().toString()).put("route_id",route.getString("id"))
                                                    .put("route_snapshot",JSONObject(route.toString())).put("performed_at",Instant.now().toString())
                                                    .put("operator",fullName).put("comment",comment).put("answers",all)
                                                store.save(payload,loginName)
                                                updateLocal();page="home";message="Обход сохранён на телефоне. Для отправки нажмите «Отправить»."
                                            },enabled=nextEnabled&&requiredAnswered(),modifier=Modifier.weight(1f)) {Text("Сохранить")}
                                        }
                                    }
                                }
                            }
                            "history" -> {
                                Header("История", "Ваши сохранённые обходы")
                                Text("Сохранено: ${counts.first} · Ожидают отправки: ${counts.second}",color=Color.Gray)
                                if(history.isEmpty()) Text("Пока нет выполненных обходов",color=Color.Gray)
                                for(item in history) {
                                    FilledPanel {
                                        Text(item.optJSONObject("route_snapshot")?.optString("name") ?: "Обход",fontWeight=FontWeight.Bold)
                                        Text(prettyDate(item.optString("performed_at")),color=Color.Gray)
                                        Text(if(item.optBoolean("_synced"))"✓ Отправлен на сервер" else "⏳ Ожидает отправки",color=if(item.optBoolean("_synced"))Color(0xFF238663) else Indigo)
                                    }
                                }
                            }
                            "settings" -> {
                                Header("Мой профиль",fullName)
                                FilledPanel {
                                    Text("Логин: $loginName",fontWeight=FontWeight.Medium)
                                    Text("Роль: ${when(userRole){"admin"->"Администратор";"editor"->"Редактор";else->"Исполнитель"}}")
                                    Text("Сервер: $server",style=MaterialTheme.typography.bodySmall)
                                    if(legacyCount>0) OutlinedButton(onClick={showLegacyConfirm=true},modifier=Modifier.fillMaxWidth()) {Text("Привязать старые обходы ($legacyCount)")}
                                    OutlinedButton(onClick={logOut()},modifier=Modifier.fillMaxWidth()) {Text("Выйти из аккаунта")}
                                }
                                FilledPanel {
                                    Text("Сменить пароль",style=MaterialTheme.typography.titleMedium)
                                    OutlinedTextField(value=oldPassword,onValueChange={oldPassword=it},label={Text("Текущий пароль")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
                                    OutlinedTextField(value=newPassword,onValueChange={newPassword=it},label={Text("Новый пароль (от 10 символов)")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
                                    Button(onClick={doNetwork {
                                        require(newPassword.length>=10) {"Новый пароль должен содержать минимум 10 символов"}
                                        val body=JSONObject().put("old_password",oldPassword).put("new_password",newPassword)
                                        http(server,token,"/api/auth/password","POST",body.toString())
                                        runOnUiThread {oldPassword="";newPassword="";logOut();message="Пароль изменён. Войдите снова."}
                                        "Пароль изменён"
                                    }},enabled=!busy,modifier=Modifier.fillMaxWidth()) {Text("Изменить пароль")}
                                }
                                Text("Для синхронизации нужен доступ к серверу. Загруженные маршруты и сохранённые результаты доступны без интернета, пока выполнен вход. Пароль на телефоне не сохраняется.",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

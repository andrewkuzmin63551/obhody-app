# Обходы 0.4 — независимая система контрольных обходов

Два клиента одной PostgreSQL-базы: адаптивная веб-панель администратора (FastAPI) и Android-приложение (Kotlin + Jetpack Compose). Ни при каких условиях не использует систему ТОиР.

## Новое в 0.4

- Вход по персональному логину и паролю, три роли: `admin`, `editor`, `inspector`.
- PBKDF2-HMAC-SHA256 с индивидуальной солью; сеансы с серверным отзывом и ограничением попыток входа.
- Веб-панель: обзор, маршрутный конструктор с редактированием, фильтры, история, экспорт CSV, сотрудники, пароль.
- Android: экран входа, имя пользователя из аккаунта, отдельные разделы, поиск маршрутов, обход по контрольным точкам, история, автономное сохранение.
- При запуске на старой БД создаёт только новые таблицы пользователей, сеансов и привязок. Старые маршруты и выполненные обходы сохраняются.

## GitHub: сборка APK из одного архива

В корень GitHub-репозитория `andrewkuzmin63551/obhody-app` загружается **сам ZIP-файл** `obhody-app.zip`, не содержимое архива. Существующий рабочий процесс `.github/workflows/main.yml` извлекает его в `source/obhody-app/android` и запускает `assembleDebug`. Результат после успешной сборки: Actions → последний запуск → Artifacts → `Obhody-APK`.

> Это исходный код, не APK. Android сборка этой версии ещё не проверена в GitHub. Тестовая версия имеет `applicationId` `ru.obhody.app.next`, чтобы ставиться рядом со старой, не удаляя её локальные результаты. Отладочные APK разных запусков GitHub могут использовать разные подписи: для регулярных обновлений потребуется стабильный ключ подписи (GitHub Secrets, не публичный репозиторий).

## Windows + PostgreSQL

Для Windows используйте отдельный архив `Obhody_Server_Windows_v0.4.zip` (есть README внутри). **Прежде чем обновлять сервер**, отправьте все результаты из старого Android-приложения и сделайте резервную копию PostgreSQL через `03_Резервная_копия.cmd`.

Новая версия больше не принимает общий `API_TOKEN`. Первый администратор создаётся при первом запуске из `BOOTSTRAP_ADMIN_LOGIN` и `BOOTSTRAP_ADMIN_PASSWORD` в `.env`. При обновлении Windows скрипт `01_Запустить.cmd` сам добавит эти переменные в существующий `.env`, не меняя пароль БД и старые данные.

Локальная разработка API:

```bash
cd backend
export DATABASE_URL="sqlite:///./obhody.db"
export BOOTSTRAP_ADMIN_LOGIN="admin"
export BOOTSTRAP_ADMIN_PASSWORD="choose-a-strong-password"
pip install -r requirements.txt pytest httpx
uvicorn app:app --host 127.0.0.1 --port 8000
pytest -q
```

Для работы с реальным PostgreSQL используйте `docker-compose.yml`, задав `POSTGRES_PASSWORD`, `API_TOKEN` (не используется авторизацией в v0.4, оставлен для совместимости конфигурации) и `BOOTSTRAP_ADMIN_PASSWORD`. Не публикуйте `.env`.

## API

- `POST /api/auth/login` — логин + пароль → Bearer-токен (до 7 дней)
- `GET /api/auth/me`, `POST /api/auth/logout`, `POST /api/auth/password`
- `GET/POST /api/users`, `PATCH /api/users/{id}` — управление сотрудниками (только admin)
- `GET/POST/PUT/DELETE /api/routes`, `POST /api/routes/{id}/activate`
- `POST /api/inspections/batch` — идемпотентная синхронизация, ID обхода создаётся на телефоне
- `GET /api/inspections`, `GET /api/dashboard`, `GET /health`

Заявления о полной безопасности возможны только после настройки HTTPS и проверки эксплуатационной схемы. HTTP используется исключительно для локального тестирования в доверенной сети; при HTTP пароль и токен передаются открытым текстом.

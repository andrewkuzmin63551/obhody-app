"""Standalone inspections: routes, checklist submissions, user accounts and sessions.

Existing 0.2 PostgreSQL tables are deliberately untouched. Upgrade adds new tables
via metadata.create_all; inspection history and route identifiers are preserved.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, create_engine, func, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./obhody.db')
ADMIN_LOGIN = os.getenv('BOOTSTRAP_ADMIN_LOGIN', 'admin').strip().lower()
ADMIN_PASSWORD = os.getenv('BOOTSTRAP_ADMIN_PASSWORD', '')
LEGACY_API_TOKEN = os.getenv('API_TOKEN', '')
ALLOW_LEGACY_API_KEY = os.getenv('ALLOW_LEGACY_API_KEY', 'false').lower() == 'true'
SESSION_DAYS = 7
PASS_ITERATIONS = 390_000

engine = create_engine(
    DATABASE_URL,
    connect_args={'check_same_thread': False} if DATABASE_URL.startswith('sqlite') else {},
    pool_pre_ping=True,
)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def naive_utc(dt: datetime) -> datetime:
    # SQLite returns naive timestamps, PostgreSQL can return aware datetimes.
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


class Base(DeclarativeBase):
    pass


# Existing schema from v0.2. Do NOT rename, alter or drop these tables.
class Route(Base):
    __tablename__ = 'routes'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, default='')
    is_active: Mapped[int] = mapped_column(Integer, default=1)
    checkpoints: Mapped[list['Checkpoint']] = relationship(cascade='all, delete-orphan', order_by='Checkpoint.position')


class Checkpoint(Base):
    __tablename__ = 'checkpoints'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    route_id: Mapped[str] = mapped_column(ForeignKey('routes.id'), index=True)
    position: Mapped[int] = mapped_column(Integer, default=0)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    questions: Mapped[list['Question']] = relationship(cascade='all, delete-orphan', order_by='Question.position')


class Question(Base):
    __tablename__ = 'questions'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    checkpoint_id: Mapped[str] = mapped_column(ForeignKey('checkpoints.id'), index=True)
    position: Mapped[int] = mapped_column(Integer, default=0)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False)
    required: Mapped[int] = mapped_column(Integer, default=1)
    options_json: Mapped[str] = mapped_column(Text, default='[]')


class Inspection(Base):
    __tablename__ = 'inspections'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    route_id: Mapped[str] = mapped_column(String(36), index=True)
    route_snapshot: Mapped[str] = mapped_column(Text, nullable=False)
    performed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    operator: Mapped[str] = mapped_column(String(150), nullable=False)
    comment: Mapped[str] = mapped_column(Text, default='')
    answers_json: Mapped[str] = mapped_column(Text, nullable=False)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


# New tables; no destructive migration of existing data.
class User(Base):
    __tablename__ = 'obhody_users'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    login: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(150))
    password_hash: Mapped[str] = mapped_column(String(240))
    role: Mapped[str] = mapped_column(String(20), default='inspector')
    is_active: Mapped[int] = mapped_column(Integer, default=1)
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class LoginSession(Base):
    __tablename__ = 'obhody_sessions'
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('obhody_users.id'), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class InspectionOwner(Base):
    __tablename__ = 'obhody_inspection_owners'
    inspection_id: Mapped[str] = mapped_column(ForeignKey('inspections.id'), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey('obhody_users.id'), index=True)


class AuditEvent(Base):
    __tablename__ = 'obhody_audit_events'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    action: Mapped[str] = mapped_column(String(60))
    detail: Mapped[str] = mapped_column(String(300), default='')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


def make_password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, PASS_ITERATIONS)
    return f'pbkdf2_sha256${PASS_ITERATIONS}${salt.hex()}${digest.hex()}'


def verify_password(password: str, password_hash: str) -> bool:
    try:
        scheme, iterations, salt, expected = password_hash.split('$')
        if scheme != 'pbkdf2_sha256' or not 100_000 <= int(iterations) <= 2_000_000:
            return False
        found = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), int(iterations))
        return hmac.compare_digest(found, bytes.fromhex(expected))
    except (ValueError, TypeError):
        return False


def audit(db: Session, actor: User | None, action: str, detail: str = '') -> None:
    db.add(AuditEvent(id=str(uuid.uuid4()), user_id=actor.id if actor else None, action=action, detail=detail[:300]))


def bootstrap_admin() -> None:
    with SessionLocal() as db:
        if db.scalar(select(func.count(User.id))) > 0:
            return
        if not ADMIN_PASSWORD or len(ADMIN_PASSWORD) < 10:
            raise RuntimeError('BOOTSTRAP_ADMIN_PASSWORD must have at least 10 characters before first start')
        if not re.fullmatch(r'[a-z0-9_.-]{3,60}', ADMIN_LOGIN):
            raise RuntimeError('BOOTSTRAP_ADMIN_LOGIN contains unsupported characters')
        admin = User(id=str(uuid.uuid4()), login=ADMIN_LOGIN, full_name='Администратор',
                     password_hash=make_password_hash(ADMIN_PASSWORD), role='admin')
        db.add(admin)
        audit(db, admin, 'bootstrap_admin', admin.login)
        db.commit()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    migrate_old_nfc_bindings()
    bootstrap_admin()
    yield


app = FastAPI(title='Обходы API', version='0.7.0', lifespan=lifespan)


def db_session():
    with SessionLocal() as db:
        yield db


def public_user(user: User) -> dict[str, Any]:
    return {'id':user.id, 'login':user.login, 'full_name':user.full_name,
            'role':user.role, 'is_active':bool(user.is_active)}


def active_user(authorization: str | None = Header(default=None), db: Session = Depends(db_session)) -> User:
    if not authorization or not authorization.startswith('Bearer '):
        raise HTTPException(401, 'Требуется вход по логину и паролю', headers={'WWW-Authenticate': 'Bearer'})
    secret = authorization[7:].strip()
    if len(secret) != 64 or not re.fullmatch('[0-9a-fA-F]{64}', secret):
        raise HTTPException(401, 'Сеанс недействителен')
    token = db.get(LoginSession, hashlib.sha256(secret.encode('ascii')).hexdigest())
    if not token or naive_utc(token.expires_at) <= utcnow():
        raise HTTPException(401, 'Сеанс истёк. Войдите заново')
    user = db.get(User, token.user_id)
    if not user or not user.is_active:
        raise HTTPException(401, 'Учётная запись отключена')
    return user


def require_roles(*roles: str):
    def role_check(user: User = Depends(active_user)) -> User:
        if user.role not in roles:
            raise HTTPException(403, 'Недостаточно прав')
        return user
    return role_check





# NFC now belongs to a physical equipment record, not to a route/checkpoint.
# New tables keep old route/checkpoint tables unchanged for safe upgrades.
class Equipment(Base):
    __tablename__ = 'obhody_equipment'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    code: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    location: Mapped[str] = mapped_column(String(200), default='')
    description: Mapped[str] = mapped_column(Text, default='')
    is_active: Mapped[int] = mapped_column(Integer, default=1)


class EquipmentTag(Base):
    __tablename__ = 'obhody_equipment_tags'
    uid: Mapped[str] = mapped_column(String(64), primary_key=True)
    equipment_id: Mapped[str] = mapped_column(ForeignKey('obhody_equipment.id'), unique=True, index=True)
    bound_by: Mapped[str | None] = mapped_column(String(36), nullable=True)
    bound_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class CheckpointEquipment(Base):
    __tablename__ = 'obhody_checkpoint_equipment'
    checkpoint_id: Mapped[str] = mapped_column(ForeignKey('checkpoints.id'), primary_key=True)
    equipment_id: Mapped[str] = mapped_column(ForeignKey('obhody_equipment.id'), index=True)
    nfc_required: Mapped[int] = mapped_column(Integer, default=0)


class NfcMigrationMarker(Base):
    __tablename__ = 'obhody_nfc_migration_markers'
    uid: Mapped[str] = mapped_column(String(64), primary_key=True)


def migrate_old_nfc_bindings() -> None:
    """Upgrade 0.5 without deleting records or rewriting previously installed tags.

    Historical NFC -> checkpoint mappings are preserved in their old table. For
    each mapping create one clearly labelled equipment placeholder, so an admin
    can later rename/merge it after verifying physical equipment.
    """
    with SessionLocal() as db:
        for old in db.scalars(select(NfcBinding)).all():
            # Do not re-bind an intentionally unbound old tag after a restart.
            if db.get(NfcMigrationMarker, old.uid):
                continue
            if db.get(EquipmentTag, old.uid):
                db.add(NfcMigrationMarker(uid=old.uid))
                continue
            cp = db.get(Checkpoint, old.checkpoint_id)
            if cp is None:
                continue
            link = db.get(CheckpointEquipment, cp.id)
            if link is None:
                equipment = Equipment(id=str(uuid.uuid4()), code='OLD-NFC-'+old.uid,
                    name='Проверить: '+cp.title[:170],
                    description='Автоматически перенесено из NFC-привязки контрольной точки. Уточните оборудование.')
                db.add(equipment)
                db.flush()
                db.add(CheckpointEquipment(checkpoint_id=cp.id, equipment_id=equipment.id,
                    nfc_required=int(old.required)))
            else:
                equipment = db.get(Equipment, link.equipment_id)
                if not equipment:
                    continue
                if db.scalar(select(EquipmentTag).where(EquipmentTag.equipment_id == equipment.id)):
                    # Preserve the old binding if this equipment already has another tag.
                    continue
            db.add(EquipmentTag(uid=old.uid, equipment_id=equipment.id,
                bound_at=old.bound_at, bound_by=old.bound_by))
            db.add(NfcMigrationMarker(uid=old.uid))
        db.commit()


def equipment_dict(e: Equipment, db: Session) -> dict[str, Any]:
    tag = db.scalar(select(EquipmentTag).where(EquipmentTag.equipment_id == e.id))
    return {'id': e.id, 'code': e.code, 'name': e.name, 'location': e.location,
            'description': e.description, 'is_active': bool(e.is_active),
            'nfc_uid': tag.uid if tag else None}


class EquipmentInput(BaseModel):
    code: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=200)
    location: str = Field(default='', max_length=200)
    description: str = Field(default='', max_length=3000)


class EquipmentPatch(BaseModel):
    code: str | None = Field(default=None, min_length=1, max_length=80)
    name: str | None = Field(default=None, min_length=1, max_length=200)
    location: str | None = Field(default=None, max_length=200)
    description: str | None = Field(default=None, max_length=3000)
    is_active: bool | None = None


def validate_equipment_code(value: str) -> str:
    value = value.strip()
    if not value or len(value)>80: raise HTTPException(422, 'Укажите код оборудования')
    return value


@app.get('/api/equipment')
def list_equipment(include_inactive: bool=False, user: User=Depends(active_user), db: Session=Depends(db_session)):
    if include_inactive and user.role not in ('admin', 'editor'):
        raise HTTPException(403, 'Недостаточно прав')
    query = select(Equipment).order_by(Equipment.location, Equipment.code)
    if not include_inactive: query = query.where(Equipment.is_active == 1)
    return [equipment_dict(e,db) for e in db.scalars(query).all()]


@app.post('/api/equipment', status_code=201)
def create_equipment(item: EquipmentInput, user: User=Depends(require_roles('admin','editor')), db: Session=Depends(db_session)):
    code=validate_equipment_code(item.code)
    if db.scalar(select(Equipment).where(Equipment.code == code)):
        raise HTTPException(409, 'Код оборудования уже существует')
    e=Equipment(id=str(uuid.uuid4()), code=code, name=item.name.strip(),
                location=item.location.strip(), description=item.description.strip())
    db.add(e);audit(db,user,'equipment_create',e.code);db.commit()
    return equipment_dict(e,db)


@app.patch('/api/equipment/{equipment_id}')
def update_equipment(equipment_id: uuid.UUID, item: EquipmentPatch, user: User=Depends(require_roles('admin','editor')),
                     db: Session=Depends(db_session)):
    e=db.get(Equipment,str(equipment_id))
    if not e: raise HTTPException(404, 'Оборудование не найдено')
    if item.code is not None:
        code=validate_equipment_code(item.code)
        existing=db.scalar(select(Equipment).where(Equipment.code == code))
        if existing and existing.id!=e.id: raise HTTPException(409, 'Код оборудования уже существует')
        e.code=code
    if item.name is not None: e.name=item.name.strip()
    if item.location is not None: e.location=item.location.strip()
    if item.description is not None: e.description=item.description.strip()
    if item.is_active is not None: e.is_active=int(item.is_active)
    audit(db,user,'equipment_update',e.code);db.commit()
    return equipment_dict(e,db)


def save_checkpoint_equipment(db: Session, cp: Checkpoint, value: 'CheckpointInput') -> None:
    link = db.get(CheckpointEquipment, cp.id)
    if 'equipment_id' not in value.model_fields_set and 'nfc_required' not in value.model_fields_set:
        return  # older clients may update routes without these fields
    equipment_id = str(value.equipment_id) if value.equipment_id else None
    if value.nfc_required and not equipment_id:
        raise HTTPException(422, 'Для обязательного NFC выберите оборудование')
    if equipment_id:
        eq=db.get(Equipment,equipment_id)
        if not eq or not eq.is_active: raise HTTPException(422,'Выберите действующее оборудование из справочника')
        if value.nfc_required and not db.scalar(select(EquipmentTag).where(EquipmentTag.equipment_id == equipment_id)):
            raise HTTPException(422, 'Сначала привяжите NFC-метку к выбранному оборудованию')
        if link:
            link.equipment_id=equipment_id
            if 'nfc_required' in value.model_fields_set: link.nfc_required=int(value.nfc_required)
        else:
            db.add(CheckpointEquipment(checkpoint_id=cp.id,equipment_id=equipment_id,
                                       nfc_required=int(value.nfc_required)))
    elif link:
        db.delete(link)


# Legacy NFC mappings, retained for migration and history. Do not drop them.
# NFC mappings are separate from the original route and checklist tables.
# No NFC data is written onto existing equipment tags.
class NfcBinding(Base):
    __tablename__ = 'obhody_nfc_bindings'
    uid: Mapped[str] = mapped_column(String(64), primary_key=True)
    checkpoint_id: Mapped[str] = mapped_column(String(36), unique=True, index=True)
    required: Mapped[int] = mapped_column(Integer, default=1)
    bound_by: Mapped[str | None] = mapped_column(String(36), nullable=True)
    bound_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class NfcScan(Base):
    __tablename__ = 'obhody_nfc_scans'
    inspection_id: Mapped[str] = mapped_column(ForeignKey('inspections.id'), primary_key=True)
    checkpoint_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    uid: Mapped[str] = mapped_column(String(64), nullable=False)
    scanned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    mapping_matched_at_sync: Mapped[int] = mapped_column(Integer, default=0)


def normalized_uid(raw: str) -> str:
    uid = re.sub(r'[\s:\-]', '', raw).upper()
    if len(uid) < 4 or len(uid) > 64 or len(uid) % 2 or not re.fullmatch('[0-9A-F]+', uid):
        raise HTTPException(422, 'UID метки должен содержать 2–32 байта HEX (например 04A1B2C3)')
    return uid


def nfc_dict(tag: EquipmentTag, db: Session) -> dict[str, Any]:
    eq = db.get(Equipment, tag.equipment_id)
    links = db.scalars(select(CheckpointEquipment).where(CheckpointEquipment.equipment_id == tag.equipment_id)).all()
    usages=[]
    for link in links:
        cp=db.get(Checkpoint,link.checkpoint_id)
        route=db.get(Route,cp.route_id) if cp else None
        if cp and route and route.is_active:
            usages.append({'checkpoint_id':cp.id,'checkpoint_title':cp.title,
                           'route_id':route.id,'route_name':route.name,'nfc_required':bool(link.nfc_required)})
    return {'uid':tag.uid, 'equipment_id':tag.equipment_id,
            'equipment_code':eq.code if eq else None, 'equipment_name':eq.name if eq else 'Удалено',
            'location':eq.location if eq else '', 'uses':usages,
            'bound_at':tag.bound_at.isoformat()}


class NfcBindInput(BaseModel):
    uid: str = Field(min_length=4, max_length=100)
    equipment_id: uuid.UUID


@app.get('/api/nfc/tags')
def nfc_tags(user: User = Depends(require_roles('admin','editor')), db: Session = Depends(db_session)):
    return [nfc_dict(t,db) for t in db.scalars(select(EquipmentTag).order_by(EquipmentTag.bound_at.desc())).all()]


@app.post('/api/nfc/bind', status_code=201)
def bind_nfc(item: NfcBindInput, user: User = Depends(require_roles('admin','editor')), db: Session = Depends(db_session)):
    uid = normalized_uid(item.uid)
    eq = db.get(Equipment, str(item.equipment_id))
    if not eq or not eq.is_active: raise HTTPException(404, 'Оборудование не найдено или отключено')
    existing_uid = db.get(EquipmentTag, uid)
    if existing_uid and existing_uid.equipment_id != eq.id:
        raise HTTPException(409, 'Эта метка уже привязана к другому оборудованию')
    existing_equipment=db.scalar(select(EquipmentTag).where(EquipmentTag.equipment_id == eq.id))
    if existing_equipment and existing_equipment.uid != uid:
        raise HTTPException(409, 'У оборудования уже есть NFC-метка. Сначала отвяжите старую')
    if not existing_uid:
        existing_uid=EquipmentTag(uid=uid,equipment_id=eq.id,bound_by=user.id)
        db.add(existing_uid)
    audit(db,user,'nfc_bind_equipment',eq.code)
    db.commit()
    return nfc_dict(existing_uid, db)


@app.delete('/api/nfc/tags/{uid}')
def unbind_nfc(uid: str, user: User = Depends(require_roles('admin','editor')), db: Session = Depends(db_session)):
    entry = db.get(EquipmentTag, normalized_uid(uid))
    if not entry: raise HTTPException(404, 'Метка не найдена')
    equipment=db.get(Equipment,entry.equipment_id)
    db.delete(entry)
    audit(db,user,'nfc_unbind_equipment',equipment.code if equipment else entry.uid)
    db.commit()
    return {'ok':True}


@app.get('/api/nfc/lookup/{uid}')
def lookup_nfc(uid: str, user: User = Depends(active_user), db: Session = Depends(db_session)):
    entry = db.get(EquipmentTag, normalized_uid(uid))
    if not entry: raise HTTPException(404, 'Метка не привязана к оборудованию')
    return nfc_dict(entry,db)


class LoginInput(BaseModel):
    login: str = Field(min_length=3, max_length=60)
    password: str = Field(min_length=1, max_length=200)


@app.post('/api/auth/login')
def login(data: LoginInput, db: Session = Depends(db_session)):
    user = db.scalar(select(User).where(User.login == data.login.strip().lower()))
    # Generic error prevents disclosure of existing account names.
    if user is None or not user.is_active:
        raise HTTPException(401, 'Неверный логин или пароль')
    if user.locked_until and naive_utc(user.locked_until) > utcnow():
        raise HTTPException(429, 'Слишком много попыток. Повторите через 5 минут')
    if not verify_password(data.password, user.password_hash):
        user.failed_attempts += 1
        if user.failed_attempts >= 5:
            user.locked_until = utcnow() + timedelta(minutes=5)
            user.failed_attempts = 0
        db.commit()
        raise HTTPException(401, 'Неверный логин или пароль')
    user.failed_attempts = 0
    user.locked_until = None
    # Store only hash of bearer token in DB. No password is stored on device.
    secret = secrets.token_hex(32)
    expires = utcnow() + timedelta(days=SESSION_DAYS)
    db.add(LoginSession(token_hash=hashlib.sha256(secret.encode('ascii')).hexdigest(),
                        user_id=user.id, expires_at=expires))
    db.commit()
    return {'access_token':secret, 'token_type':'bearer', 'expires_at':expires.isoformat(), 'user':public_user(user)}


@app.get('/api/auth/me')
def me(user: User = Depends(active_user)):
    return public_user(user)


@app.post('/api/auth/logout')
def logout(authorization: str | None = Header(default=None), user: User = Depends(active_user), db: Session = Depends(db_session)):
    token_hash = hashlib.sha256(authorization[7:].strip().encode('ascii')).hexdigest()
    token = db.get(LoginSession, token_hash)
    if token:
        db.delete(token)
        db.commit()
    return {'ok': True}


class PasswordChange(BaseModel):
    old_password: str
    new_password: str = Field(min_length=10, max_length=200)


@app.post('/api/auth/password')
def change_password(body: PasswordChange, user: User = Depends(active_user), db: Session = Depends(db_session)):
    if not verify_password(body.old_password, user.password_hash):
        raise HTTPException(400, 'Текущий пароль неверный')
    if body.old_password == body.new_password:
        raise HTTPException(400, 'Новый пароль должен отличаться от старого')
    user.password_hash = make_password_hash(body.new_password)
    db.query(LoginSession).filter(LoginSession.user_id == user.id).delete(synchronize_session=False)
    audit(db, user, 'password_change')
    db.commit()
    return {'ok':True, 'reauth_required': True}


class UserCreate(BaseModel):
    login: str = Field(pattern=r'^[a-zA-Z0-9_.-]{3,60}$')
    full_name: str = Field(min_length=2, max_length=150)
    password: str = Field(min_length=10, max_length=200)
    role: str = Field(pattern=r'^(admin|editor|inspector)$')


class UserPatch(BaseModel):
    full_name: str | None = Field(default=None, min_length=2, max_length=150)
    role: str | None = Field(default=None, pattern=r'^(admin|editor|inspector)$')
    is_active: bool | None = None
    password: str | None = Field(default=None, min_length=10, max_length=200)


@app.get('/api/users')
def users(user: User = Depends(require_roles('admin')), db: Session = Depends(db_session)):
    return [public_user(u) for u in db.scalars(select(User).order_by(User.login)).all()]


@app.post('/api/users', status_code=201)
def create_user(body: UserCreate, user: User = Depends(require_roles('admin')), db: Session = Depends(db_session)):
    name = body.login.lower()
    if db.scalar(select(User).where(User.login == name)):
        raise HTTPException(409, 'Такой логин уже существует')
    entry = User(id=str(uuid.uuid4()), login=name, full_name=body.full_name.strip(),
                 password_hash=make_password_hash(body.password), role=body.role)
    db.add(entry)
    audit(db, user, 'create_user', name)
    db.commit()
    return public_user(entry)


@app.patch('/api/users/{user_id}')
def update_user(user_id: str, body: UserPatch, actor: User = Depends(require_roles('admin')), db: Session = Depends(db_session)):
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(404, 'Пользователь не найден')
    if target.id == actor.id and (body.is_active is False or (body.role is not None and body.role != 'admin')):
        raise HTTPException(400, 'Нельзя отключить себя или снять с себя роль администратора')
    if target.role == 'admin' and (body.is_active is False or (body.role and body.role != 'admin')):
        other_admin = db.scalar(select(func.count(User.id)).where(User.role == 'admin', User.is_active == 1, User.id != target.id))
        if not other_admin:
            raise HTTPException(400, 'Нельзя отключить последнего администратора')
    if body.full_name is not None: target.full_name = body.full_name.strip()
    if body.role is not None: target.role = body.role
    if body.is_active is not None: target.is_active = int(body.is_active)
    if body.password is not None:
        target.password_hash = make_password_hash(body.password)
        target.failed_attempts = 0
        target.locked_until = None
    if body.password is not None or body.is_active is False:
        db.query(LoginSession).filter(LoginSession.user_id == target.id).delete(synchronize_session=False)
    audit(db, actor, 'update_user', target.login)
    db.commit()
    return public_user(target)


class QuestionInput(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    kind: str = Field(pattern=r'^(status|text|number|choice)$')
    required: bool = True
    options: list[str] = Field(default_factory=list)


class CheckpointInput(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    id: uuid.UUID | None = None  # preserve checkpoint identity during route edits
    questions: list[QuestionInput] = Field(min_length=1)
    equipment_id: uuid.UUID | None = None
    nfc_required: bool = False


class RouteInput(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    description: str = Field(default='', max_length=3000)
    checkpoints: list[CheckpointInput] = Field(min_length=1)


def route_dict(route: Route, db: Session) -> dict[str, Any]:
    cp_ids=[cp.id for cp in route.checkpoints]
    links={x.checkpoint_id:x for x in db.scalars(select(CheckpointEquipment).where(
        CheckpointEquipment.checkpoint_id.in_(cp_ids))).all()} if cp_ids else {}
    tags={t.equipment_id:t for t in db.scalars(select(EquipmentTag)).all()}
    equipment={x.id:x for x in db.scalars(select(Equipment)).all()}
    checkpoints=[]
    for cp in route.checkpoints:
        link=links.get(cp.id)
        eq=equipment.get(link.equipment_id) if link else None
        tag=tags.get(eq.id) if eq else None
        checkpoints.append({'id':cp.id,'title':cp.title,
            'equipment_id':eq.id if eq else None,
            'equipment_code':eq.code if eq else None,
            'equipment_name':eq.name if eq else None,
            'nfc_uid':tag.uid if tag else None,
            'nfc_required':bool(link.nfc_required) if link else False,
            'questions':[{'id':q.id, 'title':q.title, 'kind':q.kind,
                         'required':bool(q.required),'options':json.loads(q.options_json)} for q in cp.questions]})
    return {'id':route.id,'name':route.name,'description':route.description,
            'is_active':bool(route.is_active),'checkpoints':checkpoints}


def fill_route(route: Route, data: RouteInput) -> set[str]:
    """Keep IDs and NFC mappings for unchanged checkpoints, even on edit/reorder."""
    route.name = data.name.strip()
    route.description = data.description.strip()
    old = list(route.checkpoints)
    old_ids = {cp.id for cp in old}
    used: set[str] = set()
    replacements: list[Checkpoint] = []
    for i, cp_data in enumerate(data.checkpoints):
        cp = None
        if cp_data.id:
            cp = next((x for x in old if x.id == str(cp_data.id) and x.id not in used), None)
            if cp is None: raise HTTPException(422, 'ID контрольной точки не принадлежит маршруту')
        else:
            cp = next((x for x in old if x.id not in used and x.title == cp_data.title.strip()), None)
        if cp is None:
            cp = Checkpoint(id=str(uuid.uuid4()), title=cp_data.title.strip(), position=i)
        else:
            cp.title = cp_data.title.strip()
            cp.position = i
            cp.questions.clear()
            used.add(cp.id)
        for j, question in enumerate(cp_data.questions):
            opts = [o.strip() for o in question.options if o.strip()]
            if question.kind == 'choice' and not opts:
                raise HTTPException(422, 'Для вопроса с выбором укажите варианты')
            cp.questions.append(Question(id=str(uuid.uuid4()), title=question.title.strip(),
                kind=question.kind, required=int(question.required),
                options_json=json.dumps(opts,ensure_ascii=False), position=j))
        replacements.append(cp)
    route.checkpoints[:] = replacements
    return old_ids - {cp.id for cp in replacements}


@app.get('/health')
def health():
    return {'status': 'ok'}


@app.get('/')
def admin_page():
    return FileResponse(os.path.join(os.path.dirname(__file__), 'static', 'index.html'))


@app.get('/api/routes')
def routes(include_inactive: bool = False, user: User = Depends(active_user), db: Session = Depends(db_session)):
    query = select(Route).order_by(Route.name)
    if include_inactive:
        if user.role not in ('admin', 'editor'):
            raise HTTPException(403, 'Недостаточно прав')
    else:
        query = query.where(Route.is_active == 1)
    return [route_dict(route, db) for route in db.scalars(query).all()]


@app.post('/api/routes', status_code=201)
def create_route(item: RouteInput, user: User = Depends(require_roles('admin','editor')), db: Session = Depends(db_session)):
    route = Route(id=str(uuid.uuid4()))
    fill_route(route, item)
    db.add(route)
    db.flush()
    for cp, cp_input in zip(route.checkpoints, item.checkpoints):
        save_checkpoint_equipment(db, cp, cp_input)
    audit(db, user, 'create_route', route.name)
    db.commit()
    return route_dict(route, db)


@app.put('/api/routes/{route_id}')
def update_route(route_id: str, item: RouteInput, user: User = Depends(require_roles('admin','editor')), db: Session = Depends(db_session)):
    route = db.get(Route, route_id)
    if not route:
        raise HTTPException(404, 'Маршрут не найден')
    removed = fill_route(route, item)
    if removed:
        for mapping in db.scalars(select(CheckpointEquipment).where(CheckpointEquipment.checkpoint_id.in_(removed))).all():
            db.delete(mapping)
    db.flush()
    for cp, cp_input in zip(route.checkpoints, item.checkpoints):
        save_checkpoint_equipment(db, cp, cp_input)
    audit(db, user, 'update_route', route.name)
    db.commit()
    return route_dict(route, db)


@app.delete('/api/routes/{route_id}')
def deactivate_route(route_id: str, user: User = Depends(require_roles('admin','editor')), db: Session = Depends(db_session)):
    route = db.get(Route, route_id)
    if not route:
        raise HTTPException(404, 'Маршрут не найден')
    route.is_active = 0
    audit(db, user, 'deactivate_route', route.name)
    db.commit()
    return {'ok': True}


@app.post('/api/routes/{route_id}/activate')
def activate_route(route_id: str, user: User = Depends(require_roles('admin','editor')), db: Session = Depends(db_session)):
    route = db.get(Route, route_id)
    if not route:
        raise HTTPException(404, 'Маршрут не найден')
    route.is_active = 1
    audit(db, user, 'activate_route', route.name)
    db.commit()
    return {'ok': True}


class NfcScanInput(BaseModel):
    checkpoint_id: uuid.UUID
    uid: str = Field(min_length=4, max_length=100)
    scanned_at: datetime


class InspectionInput(BaseModel):
    id: uuid.UUID
    route_id: uuid.UUID
    route_snapshot: dict[str, Any]
    performed_at: datetime
    operator: str | None = Field(default=None, max_length=150) # old Android local history compatibility
    comment: str = Field(default='', max_length=10000)
    answers: list[dict[str, Any]] = Field(min_length=1)
    nfc_scans: list['NfcScanInput'] = Field(default_factory=list, max_length=100)


@app.post('/api/inspections/batch')
def batch(items: list[InspectionInput], user: User = Depends(active_user), db: Session = Depends(db_session)):
    if len(items) > 100:
        raise HTTPException(413, 'Максимум 100 результатов за запрос')
    if len({str(i.id) for i in items}) != len(items):
        raise HTTPException(422, 'Повторяющиеся ID результатов')
    ids: list[str] = []
    for item in items:
        inspection_id = str(item.id)
        if str(item.route_snapshot.get('id', '')) != str(item.route_id):
            raise HTTPException(422, 'Маршрут результата не соответствует снимку маршрута')
        exists = db.get(Inspection, inspection_id)
        if exists:
            if exists.route_id != str(item.route_id):
                raise HTTPException(409, 'Конфликт идентификатора результата')
            owner = db.get(InspectionOwner, inspection_id)
            if owner and owner.user_id != user.id:
                raise HTTPException(409, 'Этот результат принадлежит другому сотруднику')
            ids.append(inspection_id)
            continue
        snapshot_cp = {str(cp.get('id')):cp for cp in item.route_snapshot.get('checkpoints', [])}
        scans = {str(scan.checkpoint_id):scan for scan in item.nfc_scans}
        if len(scans) != len(item.nfc_scans):
            raise HTTPException(422, 'Одна метка не может быть отсканирована дважды для той же точки')
        for cp_id, scan in scans.items():
            if cp_id not in snapshot_cp:
                raise HTTPException(422, 'NFC-метка не принадлежит контрольной точке маршрута')
            if snapshot_cp[cp_id].get('nfc_uid') and normalized_uid(scan.uid) != snapshot_cp[cp_id]['nfc_uid']:
                raise HTTPException(422, 'Неверная NFC-метка для контрольной точки')
        for cp_id, cp in snapshot_cp.items():
            if cp.get('nfc_required') and (cp_id not in scans or normalized_uid(scans[cp_id].uid) != cp.get('nfc_uid')):
                raise HTTPException(422, 'Обязательная NFC-метка контрольной точки не считана')
        db.add(Inspection(id=inspection_id, route_id=str(item.route_id),
            route_snapshot=json.dumps(item.route_snapshot, ensure_ascii=False),
            performed_at=item.performed_at, operator=user.full_name,
            comment=item.comment, answers_json=json.dumps(item.answers, ensure_ascii=False)))
        db.add(InspectionOwner(inspection_id=inspection_id, user_id=user.id))
        for cp_id, scan in scans.items():
            link = db.get(CheckpointEquipment,cp_id)
            current = db.scalar(select(EquipmentTag).where(EquipmentTag.equipment_id == link.equipment_id)) if link else None
            db.add(NfcScan(inspection_id=inspection_id,checkpoint_id=cp_id,uid=normalized_uid(scan.uid),
                scanned_at=scan.scanned_at, mapping_matched_at_sync=int(bool(current and current.uid == normalized_uid(scan.uid)))))
        ids.append(inspection_id)
    if ids:
        audit(db, user, 'upload_inspections', str(len(ids)))
    db.commit()
    return {'saved_ids': ids}


@app.get('/api/inspections')
def inspections(limit: int = Query(250, ge=1, le=1000), user: User = Depends(active_user), db: Session = Depends(db_session)):
    query = select(Inspection)
    if user.role == 'inspector':
        query = query.join(InspectionOwner, InspectionOwner.inspection_id == Inspection.id).where(InspectionOwner.user_id == user.id)
    rows = db.scalars(query.order_by(Inspection.received_at.desc()).limit(limit)).all()
    return [{'id':r.id, 'route_id':r.route_id, 'route':json.loads(r.route_snapshot).get('name',''),
             'operator':r.operator, 'performed_at':r.performed_at.isoformat(), 'comment':r.comment,
             'answers':json.loads(r.answers_json), 'route_snapshot':json.loads(r.route_snapshot),
             'nfc_scans':[{'checkpoint_id':n.checkpoint_id,'uid':n.uid,'scanned_at':n.scanned_at.isoformat(),
                           'mapping_matched_at_sync':bool(n.mapping_matched_at_sync)}
                          for n in db.scalars(select(NfcScan).where(NfcScan.inspection_id == r.id)).all()]} for r in rows]


@app.get('/api/dashboard')
def dashboard(user: User = Depends(active_user), db: Session = Depends(db_session)):
    nroutes = db.scalar(select(func.count(Route.id)).where(Route.is_active == 1))
    if user.role == 'inspector':
        q = select(func.count(Inspection.id)).join(InspectionOwner, InspectionOwner.inspection_id == Inspection.id).where(InspectionOwner.user_id == user.id)
    else:
        q = select(func.count(Inspection.id))
    nresults = db.scalar(q)
    return {'routes':nroutes, 'inspections':nresults,
            'users':db.scalar(select(func.count(User.id)).where(User.is_active == 1)) if user.role == 'admin' else None}

"""Integration tests for auth, permissions, legacy schema and results."""
import os
import tempfile
import uuid
from pathlib import Path

f = tempfile.TemporaryDirectory()
os.environ['DATABASE_URL'] = 'sqlite:///' + str(Path(f.name) / 'test.db')
os.environ['BOOTSTRAP_ADMIN_LOGIN'] = 'admin'
os.environ['BOOTSTRAP_ADMIN_PASSWORD'] = 'initial-testing-password-!'

from fastapi.testclient import TestClient
from app import app, engine, Base, SessionLocal, Route, Checkpoint, Question, Inspection, User, make_password_hash, verify_password


def sign_in(client, login='admin', password='initial-testing-password-!'):
    response = client.post('/api/auth/login', json={'login':login,'password':password})
    assert response.status_code == 200, response.text
    assert response.json()['user']['login'] == login
    return {'Authorization':'Bearer ' + response.json()['access_token']}


def test_existing_tables_remain_unchanged():
    # Populate old v0.2 tables first, simulating an upgrade with real stored data.
    old_tables=[Route.__table__, Checkpoint.__table__, Question.__table__, Inspection.__table__]
    Base.metadata.create_all(engine, tables=old_tables)
    with SessionLocal() as db:
        existing=Route(id=str(uuid.uuid4()),name='Старый маршрут',description='Сохранить',is_active=1)
        cp=Checkpoint(id=str(uuid.uuid4()),title='Вход',position=0)
        cp.questions.append(Question(id=str(uuid.uuid4()),title='Исправен?',kind='status',required=1,options_json='[]',position=0))
        existing.checkpoints.append(cp)
        db.add(existing)
        db.commit()
        route_id=existing.id
    with TestClient(app) as client:
        auth=sign_in(client)
        routes=client.get('/api/routes',headers=auth).json()
        assert len(routes)==1 and routes[0]['id']==route_id
        assert client.get('/api/routes').status_code==401
        assert client.get('/health').json()=={'status':'ok'}
        assert client.get('/api/auth/me',headers=auth).json()['role']=='admin'


def test_roles_routes_results_and_revocation():
    with TestClient(app) as client:
        admin=sign_in(client)
        user=client.post('/api/users',headers=admin,json={'login':'ivan','full_name':'Иван Иванов','password':'strong-test-password-2026','role':'inspector'})
        assert user.status_code==201, user.text
        uid=user.json()['id']
        inspector=sign_in(client,'ivan','strong-test-password-2026')
        assert client.get('/api/users',headers=inspector).status_code==403
        assert client.post('/api/routes',headers=inspector,json={'name':'Новый','checkpoints':[{'title':'Дверь','questions':[{'title':'Замок?','kind':'status'}]}]}).status_code==403
        route=client.post('/api/routes',headers=admin,json={'name':'Склад','checkpoints':[{'title':'Ворота','questions':[{'title':'Замок?','kind':'status'}]}]})
        assert route.status_code==201, route.text
        route=route.json()
        assert len(client.get('/api/routes',headers=inspector).json())==2
        item={'id':str(uuid.uuid4()),'route_id':route['id'],'route_snapshot':route,
              'performed_at':'2026-11-07T09:00:00Z','operator':'Поддельное имя','answers':[{'question':'Замок?','question_id':route['checkpoints'][0]['questions'][0]['id'],'value':'Норма'}]}
        for _ in range(2):
            res=client.post('/api/inspections/batch',headers=inspector,json=[item]); assert res.status_code==200,res.text
        rows=client.get('/api/inspections',headers=admin).json()
        assert len(rows)==1 and rows[0]['operator']=='Иван Иванов' # client cannot forge operator
        assert len(client.get('/api/inspections',headers=inspector).json())==1
        updated=client.put('/api/routes/'+route['id'],headers=admin,json={'name':'Склад обновлён','checkpoints':[{'title':'Ворота','questions':[{'title':'Проверено?','kind':'status'}]}]})
        assert updated.status_code==200, updated.text
        assert client.get('/api/inspections',headers=admin).json()[0]['route']=='Склад' # immutable snapshot
        assert client.delete('/api/routes/'+route['id'],headers=admin).status_code==200
        assert client.post('/api/routes/'+route['id']+'/activate',headers=admin).status_code==200
        assert client.patch('/api/users/'+uid,headers=admin,json={'is_active':False}).status_code==200
        assert client.get('/api/auth/me',headers=inspector).status_code==401


def test_change_password_and_lockout():
    with TestClient(app) as client:
        admin=sign_in(client)
        res=client.post('/api/users',headers=admin,json={'login':'editor','full_name':'Редактор Проверок','password':'1234567890Editor!','role':'editor'})
        assert res.status_code==201
        session=sign_in(client,'editor','1234567890Editor!')
        result=client.post('/api/auth/password',headers=session,json={'old_password':'1234567890Editor!','new_password':'new-password-2026!!!'})
        assert result.status_code==200
        assert client.get('/api/auth/me',headers=session).status_code==401
        sign_in(client,'editor','new-password-2026!!!')
        for _ in range(4):
            assert client.post('/api/auth/login',json={'login':'editor','password':'wrong'}).status_code==401
        assert client.post('/api/auth/login',json={'login':'editor','password':'wrong'}).status_code==401
        assert client.post('/api/auth/login',json={'login':'editor','password':'new-password-2026!!!'}).status_code==429


def test_password_hash_is_salted():
    a=make_password_hash('this-is-a-good-password')
    b=make_password_hash('this-is-a-good-password')
    assert a != b
    assert verify_password('this-is-a-good-password',a)
    assert not verify_password('wrong',a)

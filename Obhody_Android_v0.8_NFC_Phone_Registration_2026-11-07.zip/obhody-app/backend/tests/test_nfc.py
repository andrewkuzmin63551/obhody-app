"""Equipment-bound NFC: single equipment, many routes, old data retained."""
import uuid
from datetime import datetime, timezone
from fastapi.testclient import TestClient
from test_api import sign_in
from app import app, SessionLocal, Route, Checkpoint, Question, NfcBinding, Equipment, EquipmentTag, CheckpointEquipment, migrate_old_nfc_bindings


def route_payload(name, equipment_id):
    return {'name':name,'checkpoints':[{'title':'Проверка двигателя', 'equipment_id':equipment_id,
        'nfc_required':True,'questions':[{'title':'Состояние','kind':'status','required':True}]}]}


def test_equipment_nfc_multiple_routes_edit_history():
    with TestClient(app) as c:
        admin = sign_in(c)
        assert c.get('/api/equipment').status_code == 401
        res = c.post('/api/equipment',headers=admin,json={'code':'TEST-CONV-1','name':'Конвейер 1','location':'Упаковка'})
        assert res.status_code == 201, res.text
        eq=res.json()
        assert not eq['nfc_uid']
        assert c.post('/api/equipment',headers=admin,json={'code':'TEST-CONV-1','name':'Дубликат'}).status_code == 409
        assert c.post('/api/nfc/bind',headers=admin,json={'uid':'04:AB:CD:EF','equipment_id':eq['id']}).status_code==201
        assert c.get('/api/equipment',headers=admin).json()[0]['nfc_uid'] == '04ABCDEF'
        r1=c.post('/api/routes',headers=admin,json=route_payload('Утренний обход',eq['id']))
        r2=c.post('/api/routes',headers=admin,json=route_payload('Вечерний обход',eq['id']))
        assert r1.status_code==201,r1.text
        assert r2.status_code==201,r2.text
        cp=r1.json()['checkpoints'][0]
        assert cp['equipment_id']==eq['id'] and cp['nfc_uid']=='04ABCDEF' and cp['nfc_required']
        tag=c.get('/api/nfc/lookup/04ABCDEF',headers=admin)
        assert tag.status_code==200 and len(tag.json()['uses'])==2
        # Route editing and reordering must keep equipment mapping.
        cp_input={'id':cp['id'],'title':'Двигатель, проверено','equipment_id':eq['id'],
                  'nfc_required':True,'questions':[{'title':'Проверка подшипника','kind':'status'}]}
        changed=c.put('/api/routes/'+r1.json()['id'],headers=admin,json={'name':'Утренний обход','checkpoints':[cp_input]})
        assert changed.status_code==200,changed.text
        assert changed.json()['checkpoints'][0]['id']==cp['id']
        assert changed.json()['checkpoints'][0]['nfc_uid']=='04ABCDEF'
        item={'id':str(uuid.uuid4()), 'route_id':changed.json()['id'],'route_snapshot':changed.json(),
              'performed_at':datetime.now(timezone.utc).isoformat(),'answers':[{'question_id':'q','value':'Норма'}]}
        assert c.post('/api/inspections/batch',headers=admin,json=[item]).status_code==422
        item['nfc_scans']=[{'checkpoint_id':cp['id'],'uid':'04ABCDEF','scanned_at':datetime.now(timezone.utc).isoformat()}]
        assert c.post('/api/inspections/batch',headers=admin,json=[item]).status_code==200
        assert c.post('/api/inspections/batch',headers=admin,json=[item]).status_code==200
        assert c.patch('/api/equipment/'+eq['id'],headers=admin,json={'name':'Конвейер №1, новый'}).status_code==200
        assert c.delete('/api/nfc/tags/04ABCDEF',headers=admin).status_code==200
        assert len(c.get('/api/inspections',headers=admin).json())>=1
        assert c.get('/api/nfc/lookup/04ABCDEF',headers=admin).status_code==404
        assert c.get('/api/equipment',headers=admin).json()[0]['name']=='Конвейер №1, новый'


def test_inspector_restricted_equipment_tag_actions():
    with TestClient(app) as c:
        admin=sign_in(c)
        login='emp'+str(uuid.uuid4())[:7]
        assert c.post('/api/users',headers=admin,json={'login':login,'full_name':'Оператор проверок',
            'password':'TestPassword2026!!','role':'inspector'}).status_code==201
        inspector=sign_in(c,login,'TestPassword2026!!')
        assert c.get('/api/equipment',headers=inspector).status_code==200
        assert c.post('/api/equipment',headers=inspector,json={'code':'A','name':'B'}).status_code==403
        assert c.get('/api/nfc/tags',headers=inspector).status_code==403
        assert c.post('/api/nfc/bind',headers=inspector,json={'uid':'04AABBCC','equipment_id':str(uuid.uuid4())}).status_code==403


def test_migrate_legacy_checkpoint_tag_to_equipment():
    with TestClient(app) as c:
        admin=sign_in(c)
        created=c.post('/api/routes',headers=admin,json={'name':'Старый маршрут NFC','checkpoints':[
            {'title':'Насос 4','questions':[{'title':'Течи?','kind':'status'}]}]})
        cp=created.json()['checkpoints'][0]['id']
        with SessionLocal() as db:
            db.add(NfcBinding(uid='04123456',checkpoint_id=cp,required=1))
            db.commit()
        migrate_old_nfc_bindings()
        migrate_old_nfc_bindings()  # must be idempotent
        updated=c.get('/api/routes',headers=admin).json()
        route=next(x for x in updated if x['id']==created.json()['id'])
        newcp=route['checkpoints'][0]
        assert newcp['nfc_uid']=='04123456'
        assert newcp['equipment_id'] and newcp['equipment_name'].startswith('Проверить:')
        assert newcp['nfc_required']
        eq=c.get('/api/equipment',headers=admin).json()
        assert any(x['nfc_uid']=='04123456' for x in eq)
        with SessionLocal() as db:
            assert db.get(NfcBinding,'04123456') is not None  # old binding never deleted

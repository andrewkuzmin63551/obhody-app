plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "ru.obhody.app"
    compileSdk = 35
    defaultConfig { applicationId = "ru.obhody.app.next"; minSdk = 26; targetSdk = 35; versionCode = 8; versionName = "0.8.0" }
    signingConfigs {
        create("permanentRelease") {
            // Keystore is generated once, stored PRIVATE, supplied by GitHub Secrets.
            // Never put the keystore or password in the project ZIP/repository.
            storeFile = file("obhody-release.p12")
            storeType = "PKCS12"
            storePassword = System.getenv("OBHODY_KEYSTORE_PASSWORD") ?: ""
            keyAlias = "obhody_release"
            keyPassword = System.getenv("OBHODY_KEYSTORE_PASSWORD") ?: ""
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("permanentRelease")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.02.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
}

"""v0.9 new features: workshops, QR PNG, schedule jobs, photos, backward compatibility."""
import io
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from PIL import Image
from fastapi.testclient import TestClient
from test_api import sign_in, f
from app import app, generate_due_tasks, SessionLocal, InspectionTask, Equipment, Workshop, InspectionPhoto
import app as mod


def test_v09_workshops_qr_scheduling_photos():
    mod.PHOTO_DIR=Path(f.name)/'photos'
    with TestClient(app) as c:
        a=sign_in(c)
        w=c.post('/api/workshops',headers=a,json={'code':'CHIPS','name':'Цех чипсов'});assert w.status_code==201,w.text
        workshop=w.json();assert c.get('/api/workshops',headers=a).json()[0]['name']=='Цех чипсов'
        eq=c.post('/api/equipment',headers=a,json={'code':'TEST09-EQ','name':'Тестовый станок','workshop_id':workshop['id']}); assert eq.status_code==201,eq.text
        eq=eq.json();assert eq['workshop_id']==workshop['id']
        qr=c.get('/api/equipment/'+eq['id']+'/qr.png',headers=a);assert qr.status_code==200,qr.text
        assert qr.headers['content-type']=='image/png' and qr.content[:8]==b'\x89PNG\r\n\x1a\n'
        route=c.post('/api/routes',headers=a,json={'name':'Утренний обход v09','checkpoints':[{'title':'Станок','equipment_id':eq['id'],'questions':[{'title':'Осмотр','kind':'status','required':True}]}]});assert route.status_code==201,route.text
        route=route.json()
        start=(datetime.now(timezone.utc)-timedelta(days=1)).date().isoformat()
        body={'title':'Каждый день','route_id':route['id'],'start_date':start,'weekdays':[0,1,2,3,4,5,6],'time_local':'00:00','timezone':'UTC'}
        sched=c.post('/api/schedules',headers=a,json=body);assert sched.status_code==201,sched.text
        tasks=c.get('/api/tasks',headers=a);assert tasks.status_code==200,tasks.text
        assert tasks.json();original={x['id'] for x in tasks.json()};generate_due_tasks()
        assert {x['id'] for x in c.get('/api/tasks',headers=a).json()}==original
        task=tasks.json()[0]
        payload={'id':str(uuid.uuid4()),'route_id':route['id'],'route_snapshot':route,
            'performed_at':datetime.now(timezone.utc).isoformat(),'comment':'Фото сделано',
            'answers':[{'checkpoint_id':route['checkpoints'][0]['id'],'question_id':route['checkpoints'][0]['questions'][0]['id'],'value':'Норма'}],
            'task_id':task['id']}
        saved=c.post('/api/inspections/batch',headers=a,json=[payload]);assert saved.status_code==200,saved.text
        assert task['id'] not in [x['id'] for x in c.get('/api/tasks',headers=a).json()]
        same=c.post('/api/inspections/batch',headers=a,json=[payload]);assert same.status_code==200,same.text
        img=Image.new('RGB',(20,20),'red');buf=io.BytesIO();img.save(buf,'JPEG');id_photo=str(uuid.uuid4())
        r=c.post(f'/api/inspections/{payload["id"]}/photos/{id_photo}',headers=a,
            params={'checkpoint_id':route['checkpoints'][0]['id']},files={'photo':('test.jpg',buf.getvalue(),'image/jpeg')})
        assert r.status_code==201,r.text
        listed=c.get('/api/inspections',headers=a).json();r0=next(x for x in listed if x['id']==payload['id'])
        assert r0['photos'][0]['id']==id_photo
        got=c.get('/api/photos/'+id_photo,headers=a)
        assert got.status_code==200 and got.content==buf.getvalue()
        assert c.get('/api/photos/'+id_photo).status_code==401
        assert c.patch('/api/equipment/'+eq['id'],headers=a,json={'workshop_id':None}).status_code==200
        assert c.get('/api/equipment',headers=a).json()[0]['workshop_id'] is None

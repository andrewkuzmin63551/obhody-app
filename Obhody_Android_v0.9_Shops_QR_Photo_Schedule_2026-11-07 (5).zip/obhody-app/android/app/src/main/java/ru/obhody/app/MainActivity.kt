package ru.obhody.app

import android.content.ContentValues
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import androidx.core.content.FileProvider
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.os.SystemClock
import android.nfc.NfcAdapter
import android.nfc.Tag
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

// SQLite schema is migrated in place. Completed and unsent results are NEVER dropped.
private class Store(context: Context) : SQLiteOpenHelper(context, "obhody_local.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE pending (id TEXT PRIMARY KEY, payload TEXT NOT NULL, synced INTEGER NOT NULL DEFAULT 0, owner_login TEXT NOT NULL DEFAULT '')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE pending ADD COLUMN owner_login TEXT NOT NULL DEFAULT ''")
    }
    fun save(payload: JSONObject, login: String) {
        writableDatabase.insertOrThrow("pending", null, ContentValues().apply {
            put("id", payload.getString("id")); put("payload", payload.toString()); put("synced", 0); put("owner_login", login)
        })
    }
    fun counts(login: String): Pair<Int, Int> {
        if (login.isBlank()) return 0 to 0
        return readableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM(CASE WHEN synced=0 THEN 1 ELSE 0 END),0) FROM pending WHERE owner_login=?",
            arrayOf(login)
        ).use { c -> c.moveToFirst(); c.getInt(0) to c.getInt(1) }
    }
    fun legacyCount(): Int = readableDatabase.rawQuery(
        "SELECT COUNT(*) FROM pending WHERE owner_login='' AND synced=0", null
    ).use { c -> c.moveToFirst(); c.getInt(0) }
    fun adoptLegacy(login: String) {
        writableDatabase.update("pending", ContentValues().apply { put("owner_login", login) },
            "owner_login='' AND synced=0", null)
    }
    fun unsynced(login: String): JSONArray {
        val arr = JSONArray()
        readableDatabase.rawQuery("SELECT payload FROM pending WHERE synced=0 AND owner_login=? LIMIT 100", arrayOf(login)).use { c ->
            while(c.moveToNext()) arr.put(JSONObject(c.getString(0)))
        }
        return arr
    }
    fun markSynced(ids: JSONArray, login: String) {
        writableDatabase.beginTransaction()
        try {
            for(i in 0 until ids.length()) {
                writableDatabase.update("pending", ContentValues().apply {put("synced",1)},
                    "id=? AND owner_login=?", arrayOf(ids.getString(i), login))
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
    fun completedRoutesToday(login: String): Set<String> {
        val today=java.time.LocalDate.now().toString()
        return history(login).filter { row ->
            runCatching { Instant.parse(row.optString("performed_at")).atZone(ZoneId.systemDefault()).toLocalDate().toString()==today }.getOrDefault(false)
        }.mapNotNull { it.optString("route_id").takeIf(String::isNotBlank) }.toSet()
    }
    fun completedTaskIds(login: String): Set<String> = history(login).mapNotNull { item ->
        item.optString("task_id").takeIf(String::isNotBlank)
    }.toSet()
    fun history(login: String): List<JSONObject> {
        val results = mutableListOf<JSONObject>()
        if (login.isBlank()) return results
        readableDatabase.rawQuery("SELECT payload, synced FROM pending WHERE owner_login=? ORDER BY rowid DESC LIMIT 60", arrayOf(login)).use { c ->
            while(c.moveToNext()) results.add(JSONObject(c.getString(0)).put("_synced", c.getInt(1) == 1))
        }
        return results
    }
}

private fun http(base: String, token: String, path: String, method: String = "GET", payload: String? = null): String {
    val normalized = base.trim().trimEnd('/')
    val url = URL(normalized + path)
    val ip = url.host.split('.')
    val localIPv4 = ip.size == 4 && ip.all { it.toIntOrNull() in 0..255 }
    val parts = if(localIPv4) ip.map { it.toInt() } else emptyList()
    val privateLan = localIPv4 && (parts[0] == 10 ||
        (parts[0] == 172 && parts[1] in 16..31) ||
        (parts[0] == 192 && parts[1] == 168))
    require(url.protocol == "https" || (url.protocol == "http" && privateLan)) {
        "Нужен HTTPS. Незащищённый HTTP допускается только для тестов в частной локальной сети"
    }
    val conn = url.openConnection() as HttpURLConnection
    try {
        conn.requestMethod = method
        conn.connectTimeout = 7000
        conn.readTimeout = 15000
        conn.setRequestProperty("Accept", "application/json")
        if(token.isNotEmpty()) conn.setRequestProperty("Authorization", "Bearer $token")
        if(payload != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val text = (if(code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use {it.readText()} ?: ""
        if(code !in 200..299) {
            val detail = runCatching { JSONObject(text).optString("detail") }.getOrDefault("")
            throw IllegalStateException(if(code == 401) "Сеанс закончился. Войдите снова" else "HTTP $code ${detail.take(160)}")
        }
        return text
    } finally {conn.disconnect()}
}

// Send photo as multipart; idempotent photo ID ensures retries do not create duplicates.
private fun uploadPhoto(base: String, token: String, inspectionId: String, photo: JSONObject) {
    val file=File(photo.getString("path"))
    require(file.isFile) {"Фото не найдено на телефоне: ${file.name}"}
    require(file.length() in 1..(8L*1024*1024)) {"Фото должно быть меньше 8 МБ"}
    val boundary="Obhody"+UUID.randomUUID().toString().replace("-", "")
    val cp=photo.getString("checkpoint_id")
    val u=URL(base.trimEnd('/')+"/api/inspections/$inspectionId/photos/${photo.getString("id")}?checkpoint_id=$cp")
    val conn=(u.openConnection() as HttpURLConnection)
    try {
        conn.requestMethod="POST";conn.connectTimeout=10000;conn.readTimeout=25000;conn.doOutput=true
        conn.setRequestProperty("Authorization","Bearer $token")
        conn.setRequestProperty("Content-Type","multipart/form-data; boundary=$boundary")
        conn.outputStream.use { output ->
            output.write(("--$boundary\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"capture.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n").toByteArray())
            FileInputStream(file).use { it.copyTo(output) }
            output.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val status=conn.responseCode
        if(status !in 200..299)throw IllegalStateException("Фото не отправлено: HTTP $status")
    } finally {conn.disconnect()}
}

private val Indigo = Color(0xFF365ED6)
private val Navy = Color(0xFF173550)
private val Canvas = Color(0xFFF4F7FD)
private fun prettyDate(iso: String): String = runCatching {
    DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault()).format(Instant.parse(iso))
}.getOrElse {iso}

@Composable
private fun FilledPanel(content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp), colors=CardDefaults.elevatedCardColors(containerColor=Color.White)) {
        Column(modifier=Modifier.fillMaxWidth().padding(17.dp), verticalArrangement=Arrangement.spacedBy(10.dp),content=content)
    }
}

@Composable
private fun Header(title: String, subtitle: String = "") {
    Column(verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold,color=Navy)
        if(subtitle.isNotBlank()) Text(subtitle,style=MaterialTheme.typography.bodyMedium,color=Color(0xFF6D7C90))
    }
}

class MainActivity : ComponentActivity() {
    private var lastTagUid by mutableStateOf("")
    private var nfcReadVersion by mutableIntStateOf(0)
    private var lastScannedUid: String = ""
    private var lastScanAt: Long = 0L
    private val nfcAdapter by lazy { NfcAdapter.getDefaultAdapter(this) }

    override fun onResume() {
        super.onResume()
        val adapter = nfcAdapter ?: return
        if (!adapter.isEnabled) return
        val flags = NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
            NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or
            NfcAdapter.FLAG_READER_NFC_BARCODE or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK
        runCatching {
            adapter.enableReaderMode(this, { tag: Tag ->
                val uid = tag.id.joinToString("") { byte -> "%02X".format(byte.toInt() and 0xFF) }
                if (uid.isNotEmpty()) {
                    // Avoid repeated reader callbacks while the phone remains on a tag.
                    val now = SystemClock.elapsedRealtime()
                    if (uid != lastScannedUid || now - lastScanAt > 2200) {
                        lastScannedUid = uid
                        lastScanAt = now
                        runOnUiThread { lastTagUid = uid; nfcReadVersion += 1 }
                    }
                }
            }, flags, null)
        }
    }

    override fun onPause() {
        runCatching { nfcAdapter?.disableReaderMode(this) }
        super.onPause()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        setContent {
            val scheme = lightColorScheme(primary=Indigo, secondary=Navy, background=Canvas, surface=Color.White)
            var server by remember { mutableStateOf(prefs.getString("server", "http://192.168.0.20:8000") ?: "") }
            var loginName by remember { mutableStateOf(prefs.getString("user_login", "") ?: "") }
            var fullName by remember { mutableStateOf(prefs.getString("user_name", "") ?: "") }
            var userRole by remember { mutableStateOf(prefs.getString("user_role", "") ?: "") }
            var token by remember { mutableStateOf(prefs.getString("auth_token", "") ?: "") }
            var password by remember { mutableStateOf("") }
            var page by remember { mutableStateOf(if(token.isNotEmpty() && loginName.isNotEmpty()) "home" else "login") }
            var routes by remember { mutableStateOf(JSONArray(prefs.getString("routes_$loginName", "[]") ?: "[]")) }
            var tasks by remember { mutableStateOf(JSONArray(prefs.getString("tasks_$loginName", "[]") ?: "[]")) }
            var selectedTaskId by remember { mutableStateOf("") }
            var capturedPhotos by remember { mutableStateOf(mapOf<String,List<Pair<String,String>>>()) }
            var pendingPhotoFile by remember { mutableStateOf<File?>(null) }
            var pendingPhotoCheckpoint by remember { mutableStateOf("") }
            var equipment by remember { mutableStateOf(JSONArray(prefs.getString("equipment_$loginName", "[]") ?: "[]")) }
            var equipmentQuery by remember { mutableStateOf("") }
            var routeQuery by remember { mutableStateOf("") }
            var selectedRouteIndex by remember { mutableIntStateOf(0) }
            var selectedCheckpoint by remember { mutableIntStateOf(0) }
            var answers by remember { mutableStateOf(mapOf<String,String>()) }
            var nfcScans by remember { mutableStateOf(mapOf<String,Pair<String,String>>()) }
            var bindTargetId by remember { mutableStateOf("") }
            var bindTargetName by remember { mutableStateOf("") }
            var pendingBindUid by remember { mutableStateOf("") }
            var registrationScanMode by remember { mutableStateOf(false) }
            var scannedRegistrationUid by remember { mutableStateOf("") }
            var unbindUid by remember { mutableStateOf("") }
            var unbindEquipmentName by remember { mutableStateOf("") }
            var showCreateEquipment by remember { mutableStateOf(false) }
            var newEquipmentCode by remember { mutableStateOf("") }
            var newEquipmentName by remember { mutableStateOf("") }
            var newEquipmentLocation by remember { mutableStateOf("") }
            var pendingNfcChoices by remember { mutableStateOf(listOf<Pair<Int,Int>>()) }
            var pendingQrChoices by remember { mutableStateOf(listOf<Pair<Int,Int>>()) }
            var comment by remember { mutableStateOf("") }
            var message by remember { mutableStateOf("") }
            var busy by remember { mutableStateOf(false) }
            var counts by remember { mutableStateOf(store.counts(loginName)) }
            var legacyCount by remember { mutableIntStateOf(store.legacyCount()) }
            var history by remember { mutableStateOf(store.history(loginName)) }
            var oldPassword by remember { mutableStateOf("") }
            var newPassword by remember { mutableStateOf("") }
            var showLegacyConfirm by remember { mutableStateOf(false) }

            fun refreshTaskCache() {
                val raw=http(server,token,"/api/tasks")
                prefs.edit().putString("tasks_$loginName",raw).apply()
                runOnUiThread {tasks=JSONArray(raw)}
            }
            val photoLauncher=rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
                val file=pendingPhotoFile
                if(saved && file!=null && file.length()>0) {
                    val entry=UUID.randomUUID().toString() to file.absolutePath
                    capturedPhotos=capturedPhotos+(pendingPhotoCheckpoint to ((capturedPhotos[pendingPhotoCheckpoint]?:emptyList())+entry))
                    message="Фото сохранено на телефоне"
                } else { file?.delete(); message="Снимок отменён" }
                pendingPhotoFile=null;pendingPhotoCheckpoint=""
            }
            val cameraPermissionLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                if(granted && pendingPhotoFile!=null) {
                    val uri=FileProvider.getUriForFile(this@MainActivity,"ru.obhody.app.next.fileprovider",pendingPhotoFile!!)
                    photoLauncher.launch(uri)
                } else {
                    pendingPhotoFile?.delete(); pendingPhotoFile=null; message="Для фото разрешите доступ к камере"
                }
            }
            val qrLauncher=rememberLauncherForActivityResult(ScanContract()) { result ->
                val content=result.contents ?: ""
                if(content.startsWith("OBHODY:EQUIPMENT:")) {
                    val eqId=content.removePrefix("OBHODY:EQUIPMENT:").trim()
                    val matches=mutableListOf<Pair<Int,Int>>()
                    for(ri in 0 until routes.length()) {
                        val cp=routes.optJSONObject(ri)?.optJSONArray("checkpoints")?:continue
                        for(ci in 0 until cp.length()) if(cp.getJSONObject(ci).optString("equipment_id")==eqId)matches.add(ri to ci)
                    }
                    if(matches.size>1) {pendingQrChoices=matches;message="Выберите обход для оборудования QR"}
                    else if(matches.isNotEmpty()) {
                        selectedRouteIndex=matches[0].first;selectedCheckpoint=matches[0].second
                        selectedTaskId=(0 until tasks.length()).map{tasks.getJSONObject(it)}.firstOrNull{it.optString("route_id")==routes.getJSONObject(selectedRouteIndex).optString("id")&&!it.optBoolean("completed") }?.optString("id")?:""
                        answers=emptyMap();nfcScans=emptyMap();capturedPhotos=emptyMap();comment="";page="form";message="QR-код оборудования считан"
                    } else {page="equipment";equipmentQuery=(0 until equipment.length()).map{equipment.getJSONObject(it)}.firstOrNull{it.optString("id")==eqId}?.optString("code")?:"";message="Оборудование найдено по QR. Активного маршрута для него пока нет."}
                } else if(content.isNotBlank())message="Неизвестный QR-код оборудования"
            }
            fun updateLocal() {
                counts=store.counts(loginName)
                history=store.history(loginName)
                legacyCount=store.legacyCount()
            }
            fun doNetwork(action: () -> String) {
                if (busy) return
                busy = true; message = ""
                Thread {
                    val result = runCatching { action() }
                    runOnUiThread { busy = false; updateLocal(); message = result.fold({it},{"Ошибка: ${it.message}"}) }
                }.start()
            }
            fun logOut() {
                val oldToken=token
                val oldServer=server
                if(oldToken.isNotBlank()) Thread { runCatching {http(oldServer,oldToken,"/api/auth/logout","POST")} }.start()
                prefs.edit().remove("auth_token").remove("user_login").remove("user_name").remove("user_role").apply()
                token="";loginName="";fullName="";userRole="";password="";routes=JSONArray();equipment=JSONArray();tasks=JSONArray();counts=0 to 0;page="login";message=""
                registrationScanMode=false;scannedRegistrationUid="";bindTargetId="";pendingBindUid="";unbindUid=""
            }
            // Refresh assigned tasks on sign-in/startup. Cached data remains usable offline.
            LaunchedEffect(token,loginName) {
                if(token.isNotBlank() && loginName.isNotBlank()) {
                    Thread {
                        runCatching {refreshTaskCache()}
                    }.start()
                }
            }
            // Reader mode works only while this activity is open; no writes to NFC tags.
            LaunchedEffect(nfcReadVersion) {
                if (nfcReadVersion <= 0 || lastTagUid.isBlank()) return@LaunchedEffect
                val uid = lastTagUid
                if (page == "login") return@LaunchedEffect
                if (registrationScanMode && (userRole=="admin" || userRole=="editor")) {
                    registrationScanMode = false
                    scannedRegistrationUid = uid
                    page = "equipment"
                    val linked = (0 until equipment.length()).map { equipment.getJSONObject(it) }
                        .firstOrNull { it.optString("nfc_uid") == uid }
                    if (linked != null) {
                        equipmentQuery = linked.optString("code")
                        message = "Метка $uid уже закреплена за ${linked.optString("name")}. При необходимости сначала отвяжите её."
                    } else {
                        equipmentQuery = ""
                        message = "Считана метка $uid. Выберите оборудование ниже и нажмите «Привязать считанную метку»."
                    }
                    return@LaunchedEffect
                }
                if (bindTargetId.isNotBlank()) {
                    pendingBindUid = uid
                    return@LaunchedEffect
                }
                val matches = mutableListOf<Pair<Int,Int>>()
                for(ri in 0 until routes.length()) {
                    val cps=routes.optJSONObject(ri)?.optJSONArray("checkpoints") ?: continue
                    for(ci in 0 until cps.length()) {
                        if(uid==cps.optJSONObject(ci)?.optString("nfc_uid"))matches.add(ri to ci)
                    }
                }
                if(page=="form") {
                    val matched=matches.firstOrNull {it.first==selectedRouteIndex}
                    if(matched==null) {
                        message="NFC относится к другому оборудованию или маршруту. Завершите текущий обход."
                    } else {
                        selectedCheckpoint=matched.second
                        val cp=routes.getJSONObject(matched.first).getJSONArray("checkpoints").getJSONObject(matched.second)
                        nfcScans=nfcScans+(cp.getString("id") to (uid to Instant.now().toString()))
                        message="NFC считана: ${cp.optString("equipment_name")}."
                    }
                } else if(matches.size > 1) {
                    pendingNfcChoices=matches
                    message="Это оборудование используется в нескольких маршрутах. Выберите обход."
                } else if(matches.isNotEmpty()) {
                    val matched=matches.first()
                    selectedRouteIndex=matched.first;selectedCheckpoint=matched.second
                    selectedTaskId=(0 until tasks.length()).map{tasks.getJSONObject(it)}.firstOrNull{it.optString("route_id")==routes.getJSONObject(selectedRouteIndex).optString("id")}?.optString("id")?:""
                    answers=emptyMap();nfcScans=emptyMap();capturedPhotos=emptyMap();comment=""
                    val cp=routes.getJSONObject(matched.first).getJSONArray("checkpoints").getJSONObject(matched.second)
                    nfcScans=nfcScans+(cp.getString("id") to (uid to Instant.now().toString()))
                    page="form"
                    message="NFC считана: ${cp.optString("equipment_name")}. Заполните проверку."
                } else {
                    val registered=(0 until equipment.length()).map { equipment.getJSONObject(it) }
                        .firstOrNull {it.optString("nfc_uid")==uid}
                    if(registered!=null) {
                        page="equipment"
                        equipmentQuery=registered.optString("code")
                        message="Найдено оборудование ${registered.optString("name")}. Его ещё не добавили в активный маршрут."
                    } else {
                        if (userRole=="admin" || userRole=="editor") {
                            page="equipment";equipmentQuery="";scannedRegistrationUid=uid
                            message="Метка $uid не зарегистрирована. Выберите оборудование для привязки."
                        } else {
                            message="Неизвестная NFC-метка $uid. Обратитесь к администратору для её регистрации."
                        }
                    }
                }
            }
            BackHandler(page=="form" || page=="history" || page=="equipment" || page=="settings") {
                bindTargetId=""; bindTargetName=""; pendingBindUid=""; registrationScanMode=false
                scannedRegistrationUid=""; unbindUid=""; page="home"
            }
            MaterialTheme(colorScheme=scheme) {
                if(showLegacyConfirm) AlertDialog(
                    onDismissRequest={showLegacyConfirm=false},
                    title={Text("Старые обходы")},
                    text={Text("Привязать $legacyCount ранее сохранённых, ещё не отправленных обходов к текущему сотруднику $fullName? Это действие нельзя отменить.")},
                    confirmButton={TextButton(onClick={store.adoptLegacy(loginName);updateLocal();showLegacyConfirm=false;message="Старые обходы привязаны"}){Text("Привязать")}},
                    dismissButton={TextButton(onClick={showLegacyConfirm=false}){Text("Отмена")}}
                )
                if(pendingQrChoices.isNotEmpty()) AlertDialog(
                    onDismissRequest={pendingQrChoices=emptyList()},
                    title={Text("Выберите маршрут по QR")},
                    text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        for(match in pendingQrChoices){
                            val route=routes.getJSONObject(match.first)
                            TextButton(onClick={
                                selectedRouteIndex=match.first;selectedCheckpoint=match.second
                                selectedTaskId=(0 until tasks.length()).map{tasks.getJSONObject(it)}.firstOrNull{it.optString("route_id")==route.optString("id")}?.optString("id")?:""
                                answers=emptyMap();nfcScans=emptyMap();capturedPhotos=emptyMap();comment="";page="form"
                                pendingQrChoices=emptyList()
                            }){Text(route.optString("name"))}
                        }
                    }},
                    confirmButton={TextButton(onClick={pendingQrChoices=emptyList()}){Text("Отмена")}}
                )
                if(pendingNfcChoices.isNotEmpty()) AlertDialog(
                    onDismissRequest={pendingNfcChoices=emptyList()},
                    title={Text("Выберите маршрут оборудования")},
                    text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        for(match in pendingNfcChoices){
                            val route=routes.getJSONObject(match.first)
                            TextButton(onClick={
                                selectedRouteIndex=match.first;selectedCheckpoint=match.second
                                selectedTaskId=(0 until tasks.length()).map{tasks.getJSONObject(it)}.firstOrNull{it.optString("route_id")==route.optString("id")}?.optString("id")?:""
                                answers=emptyMap();nfcScans=emptyMap();capturedPhotos=emptyMap();comment=""
                                val cp=route.getJSONArray("checkpoints").getJSONObject(match.second)
                                nfcScans=nfcScans+(cp.getString("id") to (lastTagUid to Instant.now().toString()))
                                page="form";message="NFC считана: ${cp.optString("equipment_name")}."
                                pendingNfcChoices=emptyList()
                            }) {Text(route.optString("name")+" — "+route.getJSONArray("checkpoints").getJSONObject(match.second).optString("title"))}
                        }
                    }},
                    confirmButton={TextButton(onClick={pendingNfcChoices=emptyList()}){Text("Отмена")}}
                )
                if (pendingBindUid.isNotEmpty()) AlertDialog(
                    onDismissRequest={pendingBindUid="";bindTargetId="";bindTargetName=""},
                    title={Text("Привязать NFC-метку?")},
                    text={Text("UID: $pendingBindUid\nОборудование: $bindTargetName\n\nМетка не будет перезаписана.")},
                    confirmButton={TextButton(onClick={
                        val uidToBind = pendingBindUid
                        val targetToBind = bindTargetId
                        pendingBindUid="";bindTargetId="";bindTargetName=""
                        doNetwork {
                            val body=JSONObject().put("uid",uidToBind).put("equipment_id",targetToBind)
                            http(server,token,"/api/nfc/bind","POST",body.toString())
                            val refreshed=http(server,token,"/api/routes")
                            val refreshedEquipment=http(server,token,"/api/equipment")
                            prefs.edit().putString("routes_$loginName",refreshed)
                                .putString("equipment_$loginName",refreshedEquipment).apply()
                            runOnUiThread {routes=JSONArray(refreshed);equipment=JSONArray(refreshedEquipment);scannedRegistrationUid=""}
                            "NFC-метка закреплена за оборудованием. Маршруты обновлены."
                        }
                    }){Text("Привязать")}},
                    dismissButton={TextButton(onClick={pendingBindUid="";bindTargetId="";bindTargetName=""}){Text("Отмена")}}
                )
                if (unbindUid.isNotEmpty()) AlertDialog(
                    onDismissRequest={unbindUid="";unbindEquipmentName=""},
                    title={Text("Отвязать NFC-метку?")},
                    text={Text("Оборудование: $unbindEquipmentName\nМетка: $unbindUid\n\nИстория выполненных обходов останется в базе. После отвязки можно назначить другую метку.")},
                    confirmButton={TextButton(onClick={
                        val uidToRemove=unbindUid
                        unbindUid="";unbindEquipmentName=""
                        doNetwork {
                            http(server,token,"/api/nfc/tags/$uidToRemove","DELETE")
                            val newEquipment=http(server,token,"/api/equipment")
                            val newRoutes=http(server,token,"/api/routes")
                            prefs.edit().putString("equipment_$loginName",newEquipment)
                                .putString("routes_$loginName",newRoutes).apply()
                            runOnUiThread {equipment=JSONArray(newEquipment);routes=JSONArray(newRoutes)}
                            "Метка отвязана. Данные прошлых обходов сохранены."
                        }
                    }) {Text("Отвязать")}},
                    dismissButton={TextButton(onClick={unbindUid="";unbindEquipmentName=""}){Text("Отмена")}}
                )
                Scaffold(containerColor=Canvas, bottomBar={
                    if(page!="login" && page!="form") NavigationBar(containerColor=Color.White) {
                        NavigationBarItem(selected=page=="home",onClick={page="home"},icon={Text("☑")},label={Text("Маршруты")})
                        NavigationBarItem(selected=page=="equipment",onClick={page="equipment"},icon={Text("⚙")},label={Text("Оборудование")})
                        NavigationBarItem(selected=page=="history",onClick={updateLocal();page="history"},icon={Text("▤")},label={Text("История")})
                        NavigationBarItem(selected=page=="settings",onClick={page="settings"},icon={Text("⚙")},label={Text("Профиль")})
                    }
                }) { insets ->
                    Column(modifier=Modifier.fillMaxSize().padding(insets).verticalScroll(rememberScrollState()).padding(18.dp),
                        verticalArrangement=Arrangement.spacedBy(16.dp)) {
                        if(page == "login") {
                            Spacer(Modifier.height(35.dp))
                            Text("✓",style=MaterialTheme.typography.displayLarge,color=Indigo)
                            Header("Обходы", "Вход для сотрудников")
                            FilledPanel {
                                OutlinedTextField(value=server,onValueChange={server=it},label={Text("Адрес сервера")},
                                    placeholder={Text("http://192.168.0.20:8000")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(value=loginName,onValueChange={loginName=it.trim()},label={Text("Логин")},
                                    singleLine=true,modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(value=password,onValueChange={password=it},label={Text("Пароль")},
                                    visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth())
                                Button(onClick={doNetwork {
                                    require(loginName.isNotBlank() && password.isNotBlank()) {"Укажите логин и пароль"}
                                    prefs.edit().putString("server",server.trim()).apply()
                                    val body=JSONObject().put("login",loginName.trim()).put("password",password)
                                    val response=JSONObject(http(server,"","/api/auth/login","POST",body.toString()))
                                    val user=response.getJSONObject("user")
                                    val receivedToken=response.getString("access_token")
                                    val receivedLogin=user.getString("login")
                                    val receivedName=user.getString("full_name")
                                    val receivedRole=user.getString("role")
                                    prefs.edit().putString("auth_token",receivedToken).putString("user_login",receivedLogin)
                                        .putString("user_name",receivedName).putString("user_role",receivedRole).apply()
                                    runOnUiThread {
                                        loginName=receivedLogin;fullName=receivedName;userRole=receivedRole
                                        token=receivedToken;password="";routes=JSONArray(prefs.getString("routes_$receivedLogin", "[]") ?: "[]")
                                        equipment=JSONArray(prefs.getString("equipment_$receivedLogin", "[]") ?: "[]")
                                        tasks=JSONArray(prefs.getString("tasks_$receivedLogin", "[]") ?: "[]")
                                        updateLocal();page="home"
                                    }
                                    "Вход выполнен"
                                }},enabled=!busy,modifier=Modifier.fillMaxWidth()) {Text(if(busy)"Подключение..." else "Войти")}
                            }
                            Text("Для тестов можно использовать HTTP внутри доверенной сети. Для реальной эксплуатации с персональными паролями обязательно настройте HTTPS.",color=Color(0xFF9B6133),style=MaterialTheme.typography.bodySmall)
                        }
                        if(page != "login") {
                            Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                                Text("✓ Обходы",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.weight(1f))
                                Text(fullName,style=MaterialTheme.typography.labelMedium,color=Color.DarkGray)
                            }
                        }
                        if(message.isNotBlank()) Surface(color=Color(0xFFE9F0FF),shape=RoundedCornerShape(12.dp)) {
                            Text(message,Modifier.fillMaxWidth().padding(13.dp),color=Navy)
                        }
                        when(page) {
                            "home" -> {
                                Header("Задания на обход","Завершённые задания автоматически исчезают с главной страницы")
                                FilledPanel {
                                    Text("◉ NFC оборудования",fontWeight=FontWeight.Bold,color=Navy)
                                    Text(when {
                                        nfcAdapter == null -> "На этом телефоне нет NFC-модуля"
                                        !nfcAdapter!!.isEnabled -> "Включите NFC в настройках телефона"
                                        else -> "Поднесите телефон к метке на оборудовании — нужная точка откроется автоматически"
                                    },color=Color.DarkGray)
                                    if(lastTagUid.isNotBlank()) Text("Последняя метка: $lastTagUid",style=MaterialTheme.typography.labelSmall)
                                    OutlinedButton(onClick={qrLauncher.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE).setPrompt("Наведите камеру на QR-код оборудования").setBeepEnabled(false))},modifier=Modifier.fillMaxWidth()) {Text("Сканировать QR-код оборудования")}
                                }
                                FilledPanel {
                                    Text("Локальные результаты",style=MaterialTheme.typography.titleMedium)
                                    Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
                                        Text("Сохранено: ${counts.first}")
                                        Text("К отправке: ${counts.second}",fontWeight=FontWeight.Bold,color=if(counts.second>0) Indigo else Color(0xFF238663))
                                    }
                                    Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                                        Button(onClick={doNetwork {
                                            val data=http(server,token,"/api/routes")
                                            val equipmentData=http(server,token,"/api/equipment")
                                            val tasksData=http(server,token,"/api/tasks")
                                            val loaded=JSONArray(data)
                                            val loadedEquipment=JSONArray(equipmentData)
                                            prefs.edit().putString("routes_$loginName",data)
                                                .putString("equipment_$loginName",equipmentData).putString("tasks_$loginName",tasksData).apply()
                                            runOnUiThread{routes=loaded;equipment=loadedEquipment;tasks=JSONArray(tasksData)}
                                            "Маршрутов загружено: ${loaded.length()}, оборудования: ${loadedEquipment.length()}"
                                        }},enabled=!busy,modifier=Modifier.weight(1f)) {Text("Обновить маршруты")}
                                        OutlinedButton(onClick={doNetwork {
                                            var sent=0
                                            while(true){
                                                val items=store.unsynced(loginName)
                                                if(items.length()==0)break
                                                val response=JSONObject(http(server,token,"/api/inspections/batch","POST",items.toString()))
                                                val ids=response.getJSONArray("saved_ids")
                                                if(ids.length()!=items.length())throw IllegalStateException("Сервер принял не все результаты")
                                                for(i in 0 until items.length()) {
                                                    val data=items.getJSONObject(i);val photoList=data.optJSONArray("_local_photos")?:JSONArray()
                                                    for(j in 0 until photoList.length()) uploadPhoto(server,token,data.getString("id"),photoList.getJSONObject(j))
                                                }
                                                store.markSynced(ids,loginName)
                                                sent+=ids.length()
                                            }
                                            refreshTaskCache()
                                            "Отправлено: $sent"
                                        }},enabled=!busy,modifier=Modifier.weight(1f)) {Text("Отправить (${counts.second})")}
                                    }
                                }
                                val completedToday=store.completedRoutesToday(loginName)
                                val completedTasks=store.completedTaskIds(loginName)
                                Text("Назначенные обходы",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Navy)
                                var activeTasks=0
                                for(ti in 0 until tasks.length()) {
                                    val task=tasks.getJSONObject(ti)
                                    if(task.optBoolean("completed")||task.optString("id") in completedTasks)continue
                                    val ri=(0 until routes.length()).firstOrNull {routes.getJSONObject(it).optString("id")==task.optString("route_id")}?:continue
                                    activeTasks++
                                    FilledPanel {
                                        Text(task.optString("route_name"),fontWeight=FontWeight.Bold,color=Navy)
                                        Text("По расписанию: ${prettyDate(task.optString("due_at"))}",color=Color.Gray)
                                        Text(task.optString("schedule_title"),color=Color.Gray)
                                        Button(onClick={selectedRouteIndex=ri;selectedTaskId=task.optString("id");selectedCheckpoint=0;answers=emptyMap();nfcScans=emptyMap();capturedPhotos=emptyMap();comment="";page="form"},modifier=Modifier.fillMaxWidth()) {Text("Начать задание")}
                                    }
                                }
                                if(activeTasks==0) Text("Нет невыполненных заданий по расписанию",color=Color.Gray)
                                Text("Дополнительные маршруты",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,color=Navy)
                                OutlinedTextField(value=routeQuery,onValueChange={routeQuery=it},label={Text("Поиск маршрута")},modifier=Modifier.fillMaxWidth())
                                var visible=0
                                for(i in 0 until routes.length()) {
                                    val route=routes.getJSONObject(i)
                                    if(!route.optString("name").contains(routeQuery,ignoreCase=true)||route.optString("id") in completedToday)continue
                                    visible++
                                    FilledPanel {
                                        Text(route.optString("name"),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,color=Navy)
                                        if(route.optString("description").isNotBlank())Text(route.optString("description"),color=Color.Gray)
                                        Text("Контрольных точек: ${route.optJSONArray("checkpoints")?.length() ?: 0}",style=MaterialTheme.typography.labelMedium)
                                        Button(onClick={selectedRouteIndex=i;selectedTaskId="";selectedCheckpoint=0;answers=emptyMap();nfcScans=emptyMap();capturedPhotos=emptyMap();comment="";message="";page="form"},modifier=Modifier.fillMaxWidth()) {Text("Начать обход")}
                                    }
                                }
                                if(visible==0) Text(if(routes.length()==0)"Маршруты ещё не загружены. Нажмите «Обновить маршруты»." else "Все маршруты за сегодня выполнены или не найдены. Выполненные смотри в Истории.",color=Color.Gray)
                            }
                            "equipment" -> {
                                Header("Оборудование", "Регистрация меток непосредственно у оборудования")
                                if (userRole=="admin" || userRole=="editor") {
                                    FilledPanel {
                                        Text("Добавление NFC-метки",fontWeight=FontWeight.Bold,color=Navy)
                                        Text("1. Нажмите «Сканировать метку». 2. Поднесите телефон к NFC. 3. Выберите оборудование ниже. 4. Подтвердите привязку.",color=Color.DarkGray)
                                        Text(when {
                                            nfcAdapter==null -> "В телефоне нет NFC-считывателя"
                                            !nfcAdapter!!.isEnabled -> "Сначала включите NFC в настройках Android"
                                            else -> "Считываем UID установленной метки, ничего на неё не записываем"
                                        },style=MaterialTheme.typography.bodySmall,color=Color.Gray)
                                        if (nfcAdapter!=null && nfcAdapter!!.isEnabled) {
                                            Button(onClick={
                                                registrationScanMode=!registrationScanMode
                                                bindTargetId="";bindTargetName="";pendingBindUid="";scannedRegistrationUid=""
                                                message=if(registrationScanMode)"Поднесите телефон к метке..." else "Считывание отменено"
                                            },modifier=Modifier.fillMaxWidth()) {
                                                Text(if(registrationScanMode)"Отменить сканирование" else "Сканировать метку и выбрать оборудование")
                                            }
                                        }
                                        if(registrationScanMode) Text("◉ Ожидание NFC-метки...",color=Indigo,fontWeight=FontWeight.Bold)
                                        if(scannedRegistrationUid.isNotEmpty()) {
                                            Text("Считан UID: $scannedRegistrationUid",fontWeight=FontWeight.Bold,color=Color(0xFF238663))
                                            val assigned = (0 until equipment.length()).map { equipment.getJSONObject(it) }
                                                .firstOrNull {it.optString("nfc_uid")==scannedRegistrationUid}
                                            if(assigned!=null) {
                                                Text("Уже привязана: ${assigned.optString("code")} — ${assigned.optString("name")}",color=Color(0xFF9B6133))
                                            } else {
                                                Text("Выберите карточку оборудования из списка ниже и нажмите «Привязать считанную метку».",color=Color.DarkGray)
                                            }
                                            TextButton(onClick={scannedRegistrationUid="";equipmentQuery=""}) {Text("Сбросить считывание")}
                                        }
                                    }
                                    OutlinedButton(onClick={showCreateEquipment=!showCreateEquipment},modifier=Modifier.fillMaxWidth()) {
                                        Text(if(showCreateEquipment)"Скрыть создание оборудования" else "+ Добавить оборудование с телефона")
                                    }
                                    if(showCreateEquipment) FilledPanel {
                                        Text("Новая карточка оборудования",fontWeight=FontWeight.Bold,color=Navy)
                                        OutlinedTextField(value=newEquipmentCode,onValueChange={newEquipmentCode=it},label={Text("Код оборудования")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                        OutlinedTextField(value=newEquipmentName,onValueChange={newEquipmentName=it},label={Text("Наименование")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                        OutlinedTextField(value=newEquipmentLocation,onValueChange={newEquipmentLocation=it},label={Text("Участок / расположение")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                        Button(onClick={doNetwork {
                                            require(newEquipmentCode.isNotBlank() && newEquipmentName.isNotBlank()) {"Укажите код и название оборудования"}
                                            val body=JSONObject().put("code",newEquipmentCode.trim())
                                                .put("name",newEquipmentName.trim()).put("location",newEquipmentLocation.trim())
                                            http(server,token,"/api/equipment","POST",body.toString())
                                            val data=http(server,token,"/api/equipment")
                                            prefs.edit().putString("equipment_$loginName",data).apply()
                                            runOnUiThread {equipment=JSONArray(data);equipmentQuery=newEquipmentCode.trim();newEquipmentCode="";newEquipmentName="";newEquipmentLocation="";showCreateEquipment=false}
                                            "Оборудование создано. Теперь привяжите NFC-метку."
                                        }},enabled=!busy,modifier=Modifier.fillMaxWidth()) {Text("Сохранить оборудование")}
                                    }
                                }
                                FilledPanel {
                                    Text("Всего оборудования: ${equipment.length()}",fontWeight=FontWeight.Bold)
                                    Text("Метки закрепляются за оборудованием, а не за маршрутами. Привязка доступна администратору и редактору.",color=Color.Gray)
                                    OutlinedButton(onClick={doNetwork {
                                        val data=http(server,token,"/api/equipment")
                                        prefs.edit().putString("equipment_$loginName",data).apply()
                                        runOnUiThread{equipment=JSONArray(data)}
                                        "Справочник обновлён"
                                    }},modifier=Modifier.fillMaxWidth(),enabled=!busy) {Text("Обновить оборудование")}
                                }
                                OutlinedTextField(value=equipmentQuery,onValueChange={equipmentQuery=it},
                                    label={Text("Поиск по коду, названию, участку")},modifier=Modifier.fillMaxWidth())
                                var displayed=0
                                for(i in 0 until equipment.length()) {
                                    val item=equipment.getJSONObject(i)
                                    val searchable="${item.optString("code")} ${item.optString("name")} ${item.optString("location")}".lowercase()
                                    if(!searchable.contains(equipmentQuery.lowercase())) continue
                                    displayed++
                                    FilledPanel {
                                        Text(item.optString("code")+" · "+item.optString("name"),fontWeight=FontWeight.Bold,color=Navy)
                                        Text("Цех: "+item.optString("workshop_name").ifBlank {"Не назначен"},color=Color.Gray)
                                        Text(item.optString("location").ifBlank {"Расположение не указано"},color=Color.Gray)
                                        val tagUid=item.optString("nfc_uid").takeUnless {it.isBlank()||it=="null"}
                                        Text(if(tagUid==null)"NFC: не привязана" else "NFC: $tagUid",color=if(tagUid==null) Color.Gray else Color(0xFF238663))
                                        if(userRole=="admin"||userRole=="editor") {
                                            val uidAssignedElsewhere = scannedRegistrationUid.isNotBlank() &&
                                                (0 until equipment.length()).any { idx ->
                                                    equipment.getJSONObject(idx).optString("nfc_uid") == scannedRegistrationUid
                                                }
                                            if(tagUid==null && scannedRegistrationUid.isNotBlank() && !uidAssignedElsewhere) {
                                                Button(onClick={
                                                    bindTargetId=item.getString("id")
                                                    bindTargetName=item.optString("code")+" · "+item.optString("name")
                                                    pendingBindUid=scannedRegistrationUid
                                                },modifier=Modifier.fillMaxWidth(),enabled=!busy) {Text("Привязать считанную метку")}
                                            }
                                            if(tagUid==null) {
                                                OutlinedButton(onClick={
                                                    registrationScanMode=false
                                                    scannedRegistrationUid=""
                                                    bindTargetId=item.getString("id")
                                                    bindTargetName=item.optString("code")+" · "+item.optString("name")
                                                    message="Приложите телефон к NFC-метке этого оборудования"
                                                },modifier=Modifier.fillMaxWidth(),enabled=!busy) {Text("Выбрать оборудование → считать NFC")}
                                            } else {
                                                OutlinedButton(onClick={
                                                    unbindUid=tagUid
                                                    unbindEquipmentName=item.optString("code")+" · "+item.optString("name")
                                                },modifier=Modifier.fillMaxWidth(),enabled=!busy) {Text("Отвязать метку")}
                                            }
                                        }
                                    }
                                }
                                if(displayed==0)Text("Оборудование не найдено. Добавьте его в веб-панели и обновите справочник.",color=Color.Gray)
                            }
                            "form" -> {
                                if(selectedRouteIndex >= routes.length()) {
                                    Text("Маршрут не найден"); Button(onClick={page="home"}){Text("Назад")}
                                } else {
                                    val route=routes.getJSONObject(selectedRouteIndex)
                                    val checkpoints=route.getJSONArray("checkpoints")
                                    val cp=checkpoints.getJSONObject(selectedCheckpoint)
                                    Header(route.getString("name"),"Контрольная точка ${selectedCheckpoint+1} из ${checkpoints.length()}")
                                    LinearProgressIndicator(progress={ (selectedCheckpoint+1).toFloat()/checkpoints.length().coerceAtLeast(1) },modifier=Modifier.fillMaxWidth())
                                    FilledPanel {
                                        Text(cp.getString("title"),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Navy)
                                        val cpId=cp.getString("id")
                                        val cpNfc=cp.optString("nfc_uid").takeIf { it.isNotBlank() && it!="null" }
                                        val scanned=nfcScans[cpId]?.first == cpNfc && cpNfc != null
                                        if(cp.optString("equipment_name").isNotBlank() && cp.optString("equipment_name")!="null")
                                            Text("Оборудование: ${cp.optString("equipment_code")} — ${cp.optString("equipment_name")}",color=Navy,fontWeight=FontWeight.SemiBold)
                                        if(cpNfc!=null) {
                                            Text(if(scanned) "✓ NFC считана: $cpNfc" else "◉ Метка $cpNfc: приложите телефон для подтверждения",
                                                color=if(scanned) Color(0xFF238663) else Indigo)
                                            if(cp.optBoolean("nfc_required") && !scanned)
                                                Text("Сканирование обязательно для завершения этой точки",color=Color(0xFF9B6133))
                                        } else {
                                            Text("NFC-метка оборудования пока не привязана",style=MaterialTheme.typography.labelMedium,color=Color.Gray)
                                        }
                                        if((userRole=="admin" || userRole=="editor") && cp.optString("equipment_id").isNotBlank() && cp.optString("equipment_id")!="null") {
                                            val targetEquipmentId=cp.getString("equipment_id")
                                            if(bindTargetId == targetEquipmentId) {
                                                OutlinedButton(onClick={bindTargetId="";bindTargetName="";pendingBindUid="";message="Привязка отменена"},modifier=Modifier.fillMaxWidth()) {
                                                    Text("Отменить ожидание NFC-метки")
                                                }
                                            } else {
                                                OutlinedButton(onClick={bindTargetId=targetEquipmentId;bindTargetName=cp.optString("equipment_name");message="Поднесите телефон к NFC-метке оборудования для привязки"},modifier=Modifier.fillMaxWidth(),enabled=cpNfc==null) {
                                                    Text("Привязать NFC к оборудованию")
                                                }
                                            }
                                        }
                                        val questions=cp.getJSONArray("questions")
                                        for(q in 0 until questions.length()) {
                                            val question=questions.getJSONObject(q)
                                            val questionId=question.getString("id")
                                            val value=answers[questionId]?:""
                                            val kind=question.getString("kind")
                                            Text(question.getString("title")+(if(question.optBoolean("required"))" *" else ""),fontWeight=FontWeight.SemiBold)
                                            if(kind=="status" || kind=="choice") {
                                                val choices=if(kind=="status") listOf("Норма","Дефект","Не проверено") else question.optJSONArray("options")?.let{ opts ->(0 until opts.length()).map { opts.getString(it) } } ?: emptyList()
                                                for(choice in choices) {
                                                    val selected=value==choice
                                                    Surface(modifier=Modifier.fillMaxWidth().clickable {answers=answers+(questionId to choice)},
                                                        shape=RoundedCornerShape(12.dp),border=BorderStroke(1.dp,if(selected) Indigo else Color(0xFFE1E7F1)),
                                                        color=if(selected)Color(0xFFEEF3FF) else Color.White) {
                                                        Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(horizontal=9.dp)) {
                                                            RadioButton(selected=selected,onClick={answers=answers+(questionId to choice)})
                                                            Text(choice,modifier=Modifier.padding(start=5.dp))
                                                        }
                                                    }
                                                }
                                            } else {
                                                OutlinedTextField(value=value,onValueChange={answers=answers+(questionId to it)},
                                                    label={Text(if(kind=="number")"Введите число" else "Введите ответ")},
                                                    keyboardOptions=KeyboardOptions(keyboardType=if(kind=="number")KeyboardType.Decimal else KeyboardType.Text),
                                                    modifier=Modifier.fillMaxWidth(),minLines=1)
                                            }
                                            HorizontalDivider(color=Color(0xFFE9EDF4))
                                        }
                                    }
                                    FilledPanel {
                                        Text("Фотофиксация",fontWeight=FontWeight.Bold,color=Navy)
                                        Text("Снимки сохраняются на телефоне без интернета и отправляются вместе с обходом",color=Color.Gray)
                                        val photosHere=capturedPhotos[cp.getString("id")]?:emptyList()
                                        Text("Фото для этой точки: ${photosHere.size}")
                                        Button(onClick={
                                            val folder=File(filesDir,"obhody-photos");folder.mkdirs()
                                            val file=File(folder,UUID.randomUUID().toString()+".jpg")
                                            pendingPhotoFile=file;pendingPhotoCheckpoint=cp.getString("id")
                                            if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) {
                                                val uri=FileProvider.getUriForFile(this@MainActivity,"ru.obhody.app.next.fileprovider",file)
                                                photoLauncher.launch(uri)
                                            } else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                        },modifier=Modifier.fillMaxWidth()) {Text("📷 Сделать фото")}
                                        if(photosHere.isNotEmpty()) TextButton(onClick={
                                            val last=photosHere.last();File(last.second).delete()
                                            capturedPhotos=capturedPhotos+(cp.getString("id") to photosHere.dropLast(1))
                                        }) {Text("Удалить последнее фото")}
                                    }
                                    if(selectedCheckpoint==checkpoints.length()-1) {
                                        OutlinedTextField(value=comment,onValueChange={comment=it},label={Text("Комментарий к обходу")},modifier=Modifier.fillMaxWidth(),minLines=3)
                                    }
                                    fun requiredAnswered(): Boolean {
                                        for(c in 0 until checkpoints.length()){
                                            val cpForValidation=checkpoints.getJSONObject(c)
                                            if(cpForValidation.optBoolean("nfc_required") &&
                                                nfcScans[cpForValidation.getString("id")]?.first != cpForValidation.optString("nfc_uid"))return false
                                            val qs=cpForValidation.getJSONArray("questions")
                                            for(q in 0 until qs.length()){
                                                val question=qs.getJSONObject(q);if(!question.optBoolean("required"))continue
                                                val v=answers[question.getString("id")]?:""
                                                if(v.isBlank() || (question.optString("kind")=="number" && v.replace(',','.').toDoubleOrNull()==null))return false
                                            }
                                        }
                                        return true
                                    }
                                    val nextEnabled=run {
                                        val qs=cp.getJSONArray("questions")
                                        var good=true
                                        for(q in 0 until qs.length()) {
                                            val question=qs.getJSONObject(q)
                                            val value=answers[question.getString("id")]?:""
                                            if(question.optBoolean("required") && (value.isBlank() || (question.optString("kind")=="number" && value.replace(',','.').toDoubleOrNull()==null))) good=false
                                        }
                                        good
                                    }
                                    val nfcCanProceed=!cp.optBoolean("nfc_required") ||
                                        nfcScans[cp.getString("id")]?.first == cp.optString("nfc_uid")
                                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxWidth()) {
                                        OutlinedButton(onClick={if(selectedCheckpoint>0)selectedCheckpoint-- else page="home"},modifier=Modifier.weight(1f)) {Text("Назад")}
                                        if(selectedCheckpoint<checkpoints.length()-1) {
                                            Button(onClick={selectedCheckpoint++},enabled=nextEnabled&&nfcCanProceed,modifier=Modifier.weight(1f)) {Text("Далее")}
                                        } else {
                                            Button(onClick={
                                                val all=JSONArray()
                                                for(c in 0 until checkpoints.length()) {
                                                    val checkpoint=checkpoints.getJSONObject(c)
                                                    val qs=checkpoint.getJSONArray("questions")
                                                    for(q in 0 until qs.length()){
                                                        val question=qs.getJSONObject(q)
                                                        all.put(JSONObject().put("checkpoint_id",checkpoint.getString("id"))
                                                            .put("question_id",question.getString("id")).put("question",question.getString("title"))
                                                            .put("value",answers[question.getString("id")]?:""))
                                                    }
                                                }
                                                val payload=JSONObject().put("id",UUID.randomUUID().toString()).put("route_id",route.getString("id"))
                                                    .put("route_snapshot",JSONObject(route.toString())).put("performed_at",Instant.now().toString())
                                                    .put("operator",fullName).put("comment",comment).put("answers",all)
                                                val scansJson=JSONArray()
                                                nfcScans.forEach { (checkpointId,scan) ->
                                                    scansJson.put(JSONObject().put("checkpoint_id",checkpointId)
                                                        .put("uid",scan.first).put("scanned_at",scan.second))
                                                }
                                                payload.put("nfc_scans",scansJson)
                                                if(selectedTaskId.isNotBlank())payload.put("task_id",selectedTaskId)
                                                val photosJson=JSONArray()
                                                capturedPhotos.forEach{(cpId,photos)->photos.forEach{(id,path)->photosJson.put(JSONObject().put("id",id).put("checkpoint_id",cpId).put("path",path))}}
                                                payload.put("_local_photos",photosJson)
                                                store.save(payload,loginName)
                                                updateLocal();page="home";message="Обход сохранён на телефоне. Для отправки нажмите «Отправить»."
                                            },enabled=nextEnabled&&nfcCanProceed&&requiredAnswered(),modifier=Modifier.weight(1f)) {Text("Сохранить")}
                                        }
                                    }
                                }
                            }
                            "history" -> {
                                Header("История", "Ваши сохранённые обходы")
                                Text("Сохранено: ${counts.first} · Ожидают отправки: ${counts.second}",color=Color.Gray)
                                if(history.isEmpty()) Text("Пока нет выполненных обходов",color=Color.Gray)
                                for(item in history) {
                                    FilledPanel {
                                        Text(item.optJSONObject("route_snapshot")?.optString("name") ?: "Обход",fontWeight=FontWeight.Bold)
                                        Text(prettyDate(item.optString("performed_at")),color=Color.Gray)
                                        Text(if(item.optBoolean("_synced"))"✓ Отправлен на сервер" else "⏳ Ожидает отправки",color=if(item.optBoolean("_synced"))Color(0xFF238663) else Indigo)
                                        Text("NFC: ${item.optJSONArray("nfc_scans")?.length() ?: 0} · Фото: ${item.optJSONArray("_local_photos")?.length() ?: 0}",color=Color.Gray)
                                    }
                                }
                            }
                            "settings" -> {
                                Header("Мой профиль",fullName)
                                FilledPanel {
                                    Text("Логин: $loginName",fontWeight=FontWeight.Medium)
                                    Text("Роль: ${when(userRole){"admin"->"Администратор";"editor"->"Редактор";else->"Исполнитель"}}")
                                    Text("Сервер: $server",style=MaterialTheme.typography.bodySmall)
                                    if(legacyCount>0) OutlinedButton(onClick={showLegacyConfirm=true},modifier=Modifier.fillMaxWidth()) {Text("Привязать старые обходы ($legacyCount)")}
                                    OutlinedButton(onClick={logOut()},modifier=Modifier.fillMaxWidth()) {Text("Выйти из аккаунта")}
                                }
                                FilledPanel {
                                    Text("Сменить пароль",style=MaterialTheme.typography.titleMedium)
                                    OutlinedTextField(value=oldPassword,onValueChange={oldPassword=it},label={Text("Текущий пароль")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
                                    OutlinedTextField(value=newPassword,onValueChange={newPassword=it},label={Text("Новый пароль (от 10 символов)")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
                                    Button(onClick={doNetwork {
                                        require(newPassword.length>=10) {"Новый пароль должен содержать минимум 10 символов"}
                                        val body=JSONObject().put("old_password",oldPassword).put("new_password",newPassword)
                                        http(server,token,"/api/auth/password","POST",body.toString())
                                        runOnUiThread {oldPassword="";newPassword="";logOut();message="Пароль изменён. Войдите снова."}
                                        "Пароль изменён"
                                    }},enabled=!busy,modifier=Modifier.fillMaxWidth()) {Text("Изменить пароль")}
                                }
                                Text("Для синхронизации нужен доступ к серверу. Загруженные маршруты и сохранённые результаты доступны без интернета, пока выполнен вход. Пароль на телефоне не сохраняется.",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
